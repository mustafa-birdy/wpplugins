<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */

$sali_socials            = Helper::socials();
$paper_options 	         = Helper::sali_get_options();
$offcanvas_menu_args     = Helper::offcanvas_menu_args();
$sali_socials            = Helper::socials();

?>
<div class="sali-contact-info-wrapper p-l-lg-45 m-b-xs-30">
    <div class="sali-contact-info-inner">
        <?php
        if ( $paper_options['address_field_title'] ){ ?>
        <h2 class="h4 m-b-xs-10"> <?php echo wp_kses_post($paper_options['address_field_title']); ?> </h2>
        <?php } ?>
        <div class="sali-contact-info">
            <address class="address">
                <?php
                if ( $paper_options['address'] ){
                    ?>
                    <p class="m-b-xs-30 mid grey-dark-three"><?php echo wp_kses_post($paper_options['address']); ?></p>
                    <?php
                }
                ?>
                <?php
                if ( $paper_options['call_now_field_title'] ){ ?>
                    <h3 class="h5"> <?php echo wp_kses_post($paper_options['call_now_field_title']); ?> </h3>
                <?php } ?>
                <?php
                if ( $paper_options['phone'] ){
                    ?>
                    <div>
                        <a class="tel" href="tel:<?php echo wp_kses_post($paper_options['phone']); ?>"><i class="fas fa-phone"></i><?php echo wp_kses_post($paper_options['phone']); ?></a>
                    </div>
                    <?php
                }
                ?>
                <?php
                if ( $paper_options['fax'] ){
                    ?>
                    <div>
                        <a class="tel" href="tel:<?php echo wp_kses_post($paper_options['fax']); ?>"><i class="fas fa-fax"></i><?php echo wp_kses_post($paper_options['fax']); ?></a>
                    </div>
                    <?php
                }
                ?>
                <?php
                if ( $paper_options['email'] ){
                    ?>
                    <div>
                        <a class="tel" href="mailto:<?php echo wp_kses_post($paper_options['email']); ?>"><i class="fas fa-envelope"></i><?php echo wp_kses_post($paper_options['email']); ?></a>
                    </div>
                    <?php
                }
                ?>
            </address>
            <!-- End of address -->
            <?php if ( $sali_socials ){ ?>
                <div class="contact-social-share m-t-xs-30">
                    <?php
                    if ( $paper_options['social_title'] ){ ?>
                        <div class="sali-social-title h5"> <?php echo wp_kses_post($paper_options['social_title']); ?> </div>
                    <?php } ?>
                    <ul class="social-share social-share__with-bg">
                        <?php foreach ( $sali_socials as $sali_social ): ?>
                            <li><a href="<?php echo esc_url( $sali_social['url'] );?>"  target="_blank"><i class="fab <?php echo esc_attr( $sali_social['icon'] );?>"></i></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php } ?>
            <!-- End of .contact-shsdf -->
        </div>
        <!-- End of .sali-contact-info -->
    </div>
    <!-- End of .sali-contact-info-inner -->
</div>
<!-- End of .sali-contact-info-wrapper -->
