<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */
$themepfix = SALI_FIX_PRFX;
$paper_options 	= Helper::sali_get_options();	
$sali_image_size  = "full";
?>
<div class="sali-single-lg2 clearfix">
	<?php if ( 'yes' === $settings['has_sec_title'] ) { ?>
		<div class="sali-single-title">
			<div class="sali-single-title-holder">
				   <<?php echo esc_html( $settings['sec_title_tag'] );?> class="sali-single-title"><?php echo wp_kses_post( $settings['title'] );?></<?php echo esc_html( $settings['sec_title_tag'] );?>>
			</div>
		</div>
	<?php } ?>

	<div class="sali-single-wrp">
		<?php
            $get_post_title = $settings['single_post_title'];
            if( $get_post_title >= 1 ) {
                $posts_ids = implode(', ', $get_post_title);
            } else {
                $posts_ids = '';
            }
            $post_names = explode(',', $posts_ids);

            $args = array(
                'post_type'             => 'post',
                'post_status'           => 'publish',
                'ignore_sticky_posts'   => 1,
                'posts_per_page'        => -1,
            );
            if ( "0" != $get_post_title ) {
                $args['post__in'] = $post_names;
            }
			$title_limit = $settings['post_title_length'];
			$content_limit = $settings['post_content_length'];
			$query = new WP_Query( $args );	
			$temp = Helper::wp_set_temp_query( $query );
			if ( $query->have_posts() ) {
				while ( $query->have_posts() ) {
				$query->the_post();
				$post_id = get_the_ID();
				$news_title = wp_trim_words( get_the_title(), $title_limit, '' );
				$excerpt = wp_trim_words(get_the_excerpt(), $content_limit, '');
				$post_comment_num = number_format_i18n( get_comments_number() );				
				$the_post_thumbnail = Helper::generate_thumbnail_image( $post_id, $sali_image_size);
				$author = $query->post_author;
		?>
		<div class="banner-home__with-post">
			<div class="banner-left-content p-l-md-80 load-anim-wrapper" style="background-image: url( <?php echo esc_url($the_post_thumbnail); ?> );">
				<div class="post-title-wrapper post-meta-primary">						
					<?php echo Helper::SaliPostMetas_loadAnim( $settings, $post_id, $author); ?>
					<<?php echo esc_html( $settings['post_title_tag'] );?> class="m-t-xs-20 m-b-xs-10 sali-post-title hover-line color-white txt-shadow  load-anim">
						<a href="<?php the_permalink(); ?>"><?php echo wp_kses_post( $news_title );?></a>
					</<?php echo esc_html( $settings['post_title_tag'] );?>>

					<?php if ( 'yes' == $settings['content_display'] ){ ?>
						<P class="big color-white m-b-xs-20 load-anim"><?php echo wp_kses_post( $excerpt ); ?></p>
					<?php } ?>
					<div class="load-anim">
						<a href="<?php the_permalink();?>" class="btn btn-primary"><?php echo esc_html__( ' READ MORE', 'paper-elements' );?></a>
					</div>
				</div>
			
			</div>
		</div>
		<!-- end -->
	<?php } ?>
	<?php } ?>
	<?php Helper::wp_reset_temp_query( $temp ); ?>
	</div>
</div>
