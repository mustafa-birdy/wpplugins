<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */
$themepfix = SALI_FIX_PRFX;
$sali_image_size1  = "sali-size-lg";
$paper_options 	= Helper::sali_get_options();	
?>
<div class="sali-single-lg clearfix">
	<?php if ( 'yes' === $settings['has_sec_title'] ) { ?>
		<div class="section-title sali-single-title">
			<div class="sali-single-title-holder">
				   <<?php echo esc_html( $settings['sec_title_tag'] );?> class="section-title title-white m-b-xs-40"><?php echo wp_kses_post( $settings['title'] );?></<?php echo esc_html( $settings['sec_title_tag'] );?>>
			</div>
		</div>
	<?php } ?>

	<div class="sali-single-wrp">
		<?php
			// category
			$PostID = $settings['single_post_id'];	
			
			$get_post_title = $settings['single_post_title'];
		
			if ( "post_id" === $settings['query_type']) {
				$args = array(
					'p' => $PostID,
					'post_status' => 'publish',
					'posts_per_page' => 1,
				);
			} else {		
				if( $get_post_title >= 1 ) { 
			    $posts_ids = implode(', ', $get_post_title); 
			        } else { $posts_ids = ''; }
			        $post_names = explode(',', $posts_ids);

			        $args = array(
			            'post_type'             => 'post',
			            'post_status'           => 'publish',
			            'ignore_sticky_posts'   => 1,
			            'posts_per_page'        => -1,
			        );
			        if ( "0" != $get_post_title ) {
			            $args['post__in'] = $post_names;
			        }
			}			



			$title_limit = $settings['post_title_length'];
			$content_limit = $settings['post_content_length'];
			$query = new WP_Query( $args );	
			$temp = Helper::wp_set_temp_query( $query );
			if ( $query->have_posts() ) {
				while ( $query->have_posts() ) {
				$query->the_post();
				$post_id = get_the_ID();
				$title = wp_trim_words( get_the_title(), $title_limit, '' );
					$author = $query->post_author;	
			?>

			<div class="sali-img-container flex-height-container video-container__type-2 m-b-xs-30">
                <a href="<?php the_permalink(); ?>" class="d-block h-100">
                    <?php Helper::get_generate_img($post_id, $class = "w-100", $settings, $sali_image_size1); ?>
                    <div class="grad-overlay grad-overlay__transparent"></div>
                    <div class="video-popup video-play-btn video-play-btn__big"></div>
                </a>
			<div class="media post-block grad-overlay__transparent position-absolute">
			    <div class="media-body media-body__big">
			        <div class="sali-media-bottom mt-auto">
			        	<?php if ( $settings['cat_display'] == 'yes' ) {  ?>						
			            <div class="post-cat-group m-b-xs-10">
						<?php 	echo sali_get_the_category($post_id);  ?>			             
			            </div>
			            <?php	} ?>
						<<?php echo esc_html( $settings['post_title_tag'] );?> class="sali-post-title hover-line">
							<a href="<?php the_permalink(); ?>"><?php echo wp_kses_post( $title );?></a>
						</<?php echo esc_html( $settings['post_title_tag'] );?>>

			            <?php echo Helper::SaliPostMetas( $settings, $post_id, $author); ?>	
			        </div>
			    </div>
			    <!-- End of .media-body -->
			</div>
			<!-- End of .post-block -->
			</div>


			

	<?php } ?>
<?php } ?>

<?php Helper::wp_reset_temp_query( $temp ); ?>
	</div>
</div>

