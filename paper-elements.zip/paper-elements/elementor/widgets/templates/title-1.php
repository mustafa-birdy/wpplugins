<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */
?>
<?php
	$btn = $attr = '';
	if ( '2' == $settings['sali_post_grid_link_type'] ) {
	    $attr  = 'href="' . get_permalink( get_page_by_path( $settings['sali_post_grid_page_link'] ) ) . '"';
	} else {
	    if ( !empty( $settings['sali_post_grid_custom_link']['url'] ) ) {
	        $attr  = 'href="' . esc_url($settings['sali_post_grid_custom_link']['url']) . '"';
	        $attr .= !empty( $settings['sali_post_grid_custom_link']['is_external'] ) ? ' target="_blank"' : '';
	        $attr .= !empty( $settings['sali_post_grid_custom_link']['nofollow'] ) ? ' rel="nofollow"' : ''; 
	    }
	}
	if ( !empty( $settings['sali_post_grid_link_text'] ) ) {
		$btn = '<a class="btn-link ml-auto" '. $attr .'>' . $settings['sali_post_grid_link_text'] . '</a>';
	}
?>

<div class="section-title d-flex m-b-xs-30">
	<<?php echo esc_html( $settings['sec_title_tag'] );?> class="sali-title sali-title__mid"><?php echo wp_kses_post( $settings['title'] );?></<?php echo esc_html( $settings['sec_title_tag'] );?>>
	<?php if ( 'yes' === $settings['has_title_button']) { ?>
			<?php echo wp_kses_post( $btn );?>
	<?php } ?>
</div>