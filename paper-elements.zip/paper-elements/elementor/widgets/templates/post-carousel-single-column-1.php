<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */

$themepfix = SALI_FIX_PRFX;
$select_image_size = $settings['image_size'];
if (isset($select_image_size) && !empty($select_image_size)) {
    $sali_image_size = $select_image_size;
} else {
    $sali_image_size = "sali-size-lg-vertical";
}
$paper_options = Helper::sali_get_options();

$btn = $attr = '';
if ('3' == $settings['sali_post_grid_link_type']) {
    $attr = 'href="' . Helper::generate_cat_link($settings['sali_post_grid_cat_link']) . '"';
} elseif ('2' == $settings['sali_post_grid_link_type']) {
    $attr = 'href="' . get_permalink(get_page_by_path($settings['sali_post_grid_page_link'])) . '"';
} else {
    if (!empty($settings['sali_post_grid_custom_link']['url'])) {
        $attr = 'href="' . esc_url($settings['sali_post_grid_custom_link']['url']) . '"';
        $attr .= !empty($settings['sali_post_grid_custom_link']['is_external']) ? ' target="_blank"' : '';
        $attr .= !empty($settings['sali_post_grid_custom_link']['nofollow']) ? ' rel="nofollow"' : '';
    }
}
if (!empty($settings['sali_post_grid_link_text'])) {
    $btn = '<a class="btn-link ml-auto" ' . $attr . '>' . $settings['sali_post_grid_link_text'] . '</a>';
}

$content_alignment = $settings['content_alignment'];
$navigation_style = $settings['navigation_style'];
if ($navigation_style == 'style2') {
    $navigation_style_class = 'nav-style-2';
} else {
    $navigation_style_class = 'nav-style-1';
}
$zoom_effect = $settings['zoom_effect'] == 'yes' ? 'zoom-effect' : 'no-effect';
$margin_bottom = $settings['margin_bottom'] == 'yes' ? 'm-b-xs-15 m-b-sm-30' : '';



$responsive = array(
    '0' => array('items' => 1),
    '480' => array('items' => 1),
    '768' => array('items' => 1),
    '992' => array('items' => 1),
    '1200' => array('items' => 1),
);
$owl_data = array(
    'navText' => array("<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"),
    'nav' => $settings['nav'] == 'yes' ? true : false,
    'dots' => false,
    'autoplay' => $settings['autoplay'] == 'yes' ? true : false,
    'autoplayTimeout' => '5000',
    'autoplaySpeed' => '200',
    'autoplayHoverPause' => true,
    'loop' => 1,
    'margin' => 30,
    'responsive' => $responsive,
    'animateIn' => 'fadeIn',
    'animateOut' => 'fadeOut',
);
$owl_data = json_encode($owl_data);
wp_enqueue_style('owl-carousel');
wp_enqueue_style('owl-theme-default');
wp_enqueue_script('owl-carousel');


?>
<div class="sali-recent-news allow-custom-height <?php echo esc_attr($content_alignment); ?>">
    <?php if ('yes' == $settings['has_sec_title'] || 'yes' == $settings['has_sec_right_button']): ?>
    <div class="section-title m-b-xs-30">
        <?php if ('yes' == $settings['has_sec_title']) { ?>
        <<?php echo esc_html($settings['sec_title_tag']); ?> class="sali-title
        sali-title__mid"><?php echo wp_kses_post($settings['title']); ?></<?php echo esc_html($settings['sec_title_tag']); ?>>
<?php } ?>
    <?php if ('yes' == $settings['has_sec_right_button']): ?>
        <?php echo wp_kses_post($btn); ?>
    <?php endif ?>
</div>
<?php endif ?>
<div class="recent-news-holder">
    <?php
    $post_sorting = $settings['post_sorting'];
    $post_ordering = $settings['post_ordering'];
    $title_limit = $settings['post_title_length'];
    $number_of_post = $settings['number_of_post'];
    $offset = $settings['offset'];
    $p_ids = array();
    if (!empty($settings['posts_not_in'])) {
        foreach ($settings['posts_not_in'] as $p_idsn) {
            $p_ids[] = $p_idsn;
        }
    }
    $cat_single_list = $settings['cat_single_list'];
    $args = array(
        'category_name' => !empty($settings['cat_single_list']) && is_array($settings['cat_single_list']) ? implode(',', $settings['cat_single_list']) : '',
        'post_status' => 'publish',
        'order' => $post_ordering,
        'posts_per_page' => $number_of_post,
        'offset' => $offset,
        'post__not_in' => $p_ids
    );
    if ($post_sorting == 'view') {
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = 'sali_views';
    } else {
        $args['orderby'] = $post_sorting;
    }
    $query = new WP_Query($args);

    $temp = Helper::wp_set_temp_query($query);

    if ($query->have_posts()) {
    ?>
    <div class="sali-post-carousel <?php echo esc_attr($navigation_style_class); ?>">
        <div class="cat-carousel-inner owl-wrap sali-nav-center">
            <div class="owl-theme owl-carousel sali-paper-carousel"
                 data-carousel-options="<?php echo esc_attr($owl_data); ?>">
                <?php
                while ($query->have_posts()) {
                $query->the_post();
                $post_id = get_the_ID();
                $post_title = wp_trim_words(get_the_title(), $title_limit, '');
                $author = $query->post_author;
                if (get_post_format()) {
                    switch (get_post_format()) {
                        case 'video':
                            $post_format_icon = '<i class="fas fa-play"></i>';
                            break;
                        case 'audio':
                            $post_format_icon = '<i class="fas fa-volume-down"></i>';
                            break;
                        case 'aside':
                            $post_format_icon = '<i class="fab fa-facebook-f"></i>';
                            break;
                        case 'gallery':
                            $post_format_icon = '<i class="fas fa-images"></i>';
                            break;
                        default:
                            $post_format_icon = '<i class="fas fa-image"></i>';
                            break;
                    }
                }

                ?>
                <div class="item">
                    <div class="sali-img-container video-container__type-2 <?php echo esc_attr($margin_bottom); ?> <?php echo esc_attr($zoom_effect); ?>">

                        <?php Helper::get_generate_thumbnail_image($post_id, $class = "img-fluid", $settings, $sali_image_size); ?>

                        <?php if (get_post_format()): ?>
                            <div class="post-format video-play-btn"><?php echo wp_kses_post($post_format_icon); ?></div>
                        <?php endif ?>

                        <div class="media post-block  position-absolute m-b-xs-30">
                            <div class="media-body media-body__big">
                                <div class="sali-media-bottom mt-auto">

                                    <?php if ($settings['cat_display'] == 'yes') { ?>
                                        <div class="post-cat-group m-b-xs-10">
                                            <?php
                                            $categories = get_the_category();
                                            $separator = ' ';
                                            $output = '';
                                            if (!empty($categories)) {
                                                foreach ($categories as $category) {
                                                    $get_color = get_term_meta($category->term_id, 'sali_category_color', true);

                                                    if ($get_color) { ?>
                                                        <a style="background:<?php echo esc_attr($get_color); ?>"
                                                           class="post-cat cat-btn btn-big bg-color-red-two"
                                                           href="<?php echo get_category_link($category->term_id); ?>"><?php echo esc_html($category->name); ?></a>
                                                    <?php } else { ?>
                                                        <a class="post-cat cat-btn btn-big bg-color-red-two"
                                                           href="<?php echo get_category_link($category->term_id); ?>"><span
                                                                    class="el-rt-cat style_2"><?php echo esc_html($category->name); ?><span
                                                                        class="titleinner"></span></span></a>
                                                    <?php }
                                                }
                                            } ?>
                                        </div>
                                    <?php } ?>
                                    <<?php echo esc_html($settings['post_title_tag']); ?> class="sali-post-title
                                    hover-line">
                                    <a href="<?php the_permalink(); ?>"><?php echo esc_html($post_title); ?></a>
                                </<?php echo esc_html($settings['post_title_tag']); ?>>

                                <?php echo Helper::SaliPostMetas($settings, $post_id, $author); ?>


                            </div>
                        </div>
                    </div>
                    <!-- End of .post-block -->
                </div>
                <!-- End of .sali-img-container -->
            </div>
            <!-- End of .item -->
            <?php } ?>
        </div>
    </div>
</div>
<!-- End of .owl-carousel -->
<?php Helper::wp_reset_temp_query($temp);
} ?>
</div>
</div>