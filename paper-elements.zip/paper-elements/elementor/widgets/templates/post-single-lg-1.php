<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */
$sali_image_size = "sali-size-lg";
$paper_options = Helper::sali_get_options();
?>
<div class="sali-single-lg clearfix">
    <?php if ('yes' === $settings['has_sec_title']) { ?>
    <div class="sali-single-title">
        <div class="sali-single-title-holder">
            <<?php echo esc_html($settings['sec_title_tag']); ?>
            class="sali-single-title"><?php echo wp_kses_post($settings['title']); ?></<?php echo esc_html($settings['sec_title_tag']); ?>
        >
    </div>
</div>
<?php } ?>
<div class="sali-single-wrp">
    <?php

    $get_post_title = $settings['single_post_title'];
    if ($get_post_title >= 1) {

        $posts_ids = implode(', ', $get_post_title);

    } else {
        $posts_ids = '';
    }
    $post_names = explode(',', $posts_ids);

    $args = array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'ignore_sticky_posts' => 1,
        'posts_per_page' => -1,
    );
    if ("0" != $get_post_title) {
        $args['post__in'] = $post_names;
    }
    $title_limit = $settings['post_title_length'];
    $content_limit = $settings['post_content_length'];
    $query = new WP_Query($args);
    $temp = Helper::wp_set_temp_query($query);
    if ($query->have_posts()) {
    while ($query->have_posts()) {
    $query->the_post();
    $post_id = get_the_ID();
    $title = wp_trim_words(get_the_title(), $title_limit, '');
    $excerpt = wp_trim_words(get_the_excerpt(), $content_limit, '');
    $author = $query->post_author;
    ?>
    <div class="sali-latest-post">
        <div class="media post-block m-b-xs-30">
            <?php if (has_post_thumbnail() && 'yes' === $settings['show_post_thumb']) { ?>
                <figure class="fig-container">
                    <?php Helper::get_generate_thumbnail_image($post_id, $class = "img-fluid m-r-xs-30", $settings, $sali_image_size); ?>
                    <?php if ('yes' === $settings['cat_display']) { ?>
                        <div class="post-cat-group m-b-xs-10">
                            <?php echo sali_get_the_category($post_id); ?>
                        </div>
                    <?php } ?>
                </figure>
            <?php } ?>
            <div class="media-body">
                <<?php echo esc_html($settings['post_title_tag']); ?> class="sali-post-title hover-line hover-line">
                <a href="<?php the_permalink(); ?>"><?php echo wp_kses_post($title); ?></a>
            </<?php echo esc_html($settings['post_title_tag']); ?>>
            <?php echo Helper::SaliPostMetas($settings, $post_id, $author); ?>
            <?php if ('yes' === $settings['content_display']) { ?>
                <P><?php echo wp_kses_post($excerpt); ?></p>
            <?php } ?>

        </div>
    </div>
</div>
<?php } ?>
<?php } ?>
<?php Helper::wp_reset_temp_query($temp); ?>
</div>
</div>
