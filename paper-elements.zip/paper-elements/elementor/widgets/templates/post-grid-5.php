<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */

$themepfix = SALI_FIX_PRFX;

$select_image_size = $settings['image_size'];
if (isset($select_image_size) && !empty($select_image_size)){
    $sali_image_size = $select_image_size;
}else{
    $sali_image_size  = "sali-size-md";
}

$paper_options 	= Helper::sali_get_options();	

if ( get_query_var('paged') ) {
	$paged = get_query_var('paged');
}
else if ( get_query_var('page') ) {
	$paged = get_query_var('page');
}
else {
	$paged = 1;
}
$col_class = "col-lg-{$settings['col_lg']} col-md-{$settings['col_md']} col-sm-{$settings['col_sm']}";
$btn = $attr = '';
$sali_post_grid_format_link = get_post_format_link($settings['sali_post_grid_format_link']) ? : '#';
if ( '4' == $settings['sali_post_grid_link_type'] ) {
   		$attr  = 'href="' . $sali_post_grid_format_link . '"';
	}elseif( '3' == $settings['sali_post_grid_link_type'] ) {
   		$attr  = 'href="' . Helper::generate_cat_link($settings['sali_post_grid_cat_link']) . '"';
	}elseif( '2' == $settings['sali_post_grid_link_type'] ) {
    	$attr  = 'href="' . get_permalink( get_page_by_path( $settings['sali_post_grid_page_link'] ) ) . '"';
	} else {
    if ( !empty( $settings['sali_post_grid_custom_link']['url'] ) ) {
        $attr  = 'href="' . esc_url($settings['sali_post_grid_custom_link']['url']) . '"';
        $attr .= !empty( $settings['sali_post_grid_custom_link']['is_external'] ) ? ' target="_blank"' : '';
        $attr .= !empty( $settings['sali_post_grid_custom_link']['nofollow'] ) ? ' rel="nofollow"' : ''; 
    }
}
if ( !empty( $settings['sali_post_grid_link_text'] ) ) {
	$btn = '<a class="btn-link ml-auto" '. $attr .'>' . $settings['sali_post_grid_link_text'] . '</a>';
}
?>
<div class="sali-recent-news allow-custom-height">
	<?php if ( 'yes' == $settings['has_sec_title'] || 'yes' == $settings['has_sec_right_button'] ): ?>
		<div class="section-title m-b-xs-30">
			<?php if ( 'yes' == $settings['has_sec_title'] ) { ?>
				<<?php echo esc_html( $settings['sec_title_tag'] );?> class="sali-title sali-title__mid"><?php echo wp_kses_post( $settings['title'] );?></<?php echo esc_html( $settings['sec_title_tag'] );?>>
			<?php } ?>
			<?php if ( 'yes' == $settings['has_sec_right_button'] ): ?>
				<?php echo wp_kses_post( $btn );?>
			<?php endif ?>
		</div>
	<?php endif ?>
	<div class="recent-news-holder row">
		<?php

			$post_sorting = $settings['post_sorting'];
			$post_ordering = $settings['post_ordering'];
			$title_limit = $settings['post_title_length'];
			$content_limit = $settings['post_content_length'];
		

            // number
            $number_of_post = $settings['number_of_post'];
            $off = (!empty($settings['offset'])) ? $settings['offset'] : 0;
            $offset = $off + (($paged - 1) * $number_of_post);
            $p_ids = array();

            // build up the array
            if ( !empty($settings['posts_not_in'])){
                foreach ( $settings['posts_not_in'] as $p_idsn ) {
                    $p_ids[] = $p_idsn;
                }
            }
			$cat_single_list = $settings['cat_single_list'];
			$args = array(
				'category_name'  => !empty($settings['cat_single_list']) && is_array($settings['cat_single_list']) ? implode(',', $settings['cat_single_list']) : '',
				'post_status' => 'publish',
				'order' => $post_ordering,
				'posts_per_page' => $number_of_post,
				'offset' => $offset,
				'paged'          => $paged,
				'post__not_in'   => $p_ids
			);
				
			if ( $post_sorting == 'view' ) {
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = 'sali_views';
			} else {
				$args['orderby'] = $post_sorting;
			}
			$query = new WP_Query( $args );
			
			$temp = Helper::wp_set_temp_query( $query );
			
			if ( $query->have_posts() ) {	
				while ( $query->have_posts() ) {
				$query->the_post();
				$post_id = get_the_ID();
				$excerpt = wp_trim_words(get_the_excerpt(), $content_limit, '');
				$ptitle = wp_trim_words(get_the_title(), $title_limit, '');
				
				$author = $query->post_author;
				?>


				<div class="<?php echo esc_attr( $col_class );?>">
		        <div class="sali-img-container m-b-xs-15 m-b-sm-30">
		            <a href="<?php the_permalink(); ?>">
		            	<?php Helper::get_generate_img($post_id, $class = "", $settings, $sali_image_size); ?>
		            	<div class="grad-overlay grad-overlay__transparent"></div>
		            </a>         
		                       
		            <div class="media post-block grad-overlay position-absolute">
		                <div class="media-body justify-content-end">
		                    <?php if ( $settings['cat_display'] ) { ?>              
		                        <div class="post-cat-group m-b-xs-10">
		                            <?php echo sali_get_the_category($post_id); ?>
		                        </div>
		                    <?php
		                    } 
		                    ?>
		                    <div class="sali-media-bottom">
		                        <<?php echo esc_html( $settings['post_title_tag'] );?> class="sali-post-title hover-line">
		                                <a href="<?php the_permalink(); ?>"><?php echo esc_html( $ptitle ); ?></a>
                                </<?php echo esc_html( $settings['post_title_tag'] );?>>

		                        <?php echo Helper::SaliPostMetas( $settings, $post_id ,$author); ?>
		                    </div>
		                </div>
		            </div>
		            <!-- End of .post-block -->
		        </div>
		        <!-- End of .sali-img-container -->
		    </div>

				
			<?php } ?>
			<?php if ( $settings['pagination_display'] == 'yes' ) { ?>
				<div class="mt20 col-sm-12 col-xs-12 pagination-wrapper"><?php Helper::pagination(); ?></div>
			<?php } ?>
		<?php Helper::wp_reset_temp_query( $temp );
	 } ?>
	</div>
</div>