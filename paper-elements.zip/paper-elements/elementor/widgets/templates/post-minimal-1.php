<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */

$themepfix = SALI_FIX_PRFX;
$paper_options 	= Helper::sali_get_options();	
?>
<div class="sali-banner-sidebar load-anim-wrapper">
	<div class="sali-banner-sidebar-media-wrapper nicescroll-container">
	<?php
		$post_sorting = $settings['post_sorting'];
		$post_ordering = $settings['post_ordering'];
		$title_limit = $settings['post_title_length'];
		$content_limit = $settings['post_content_length'];
        $number_of_post = $settings['number_of_post'];
        $offset = $settings['offset'];
        $p_ids = array();
        if ( !empty($settings['posts_not_in'])){
            foreach ( $settings['posts_not_in'] as $p_idsn ) {
                $p_ids[] = $p_idsn;
            }
        }
		$cat_single_list = $settings['cat_single_list'];		
		$args = array(
			'category_name'  => !empty($settings['cat_single_list']) && is_array($settings['cat_single_list']) ? implode(',', $settings['cat_single_list']) : '',
			'post_status' => 'publish',
			'order' => $post_ordering,
			'posts_per_page' => $number_of_post,		
			'offset' => $offset,
			'post__not_in'   => $p_ids
		);
			
		if ( $post_sorting == 'view' ) {
			$args['orderby']  = 'meta_value_num';
			$args['meta_key'] = 'sali_views';
		} else {
			$args['orderby'] = $post_sorting;
		}
		$query = new WP_Query( $args );		
		$temp = Helper::wp_set_temp_query( $query );		
			if ( $query->have_posts() ) {	
				while ( $query->have_posts() ) {
				$query->the_post();
				$post_id = get_the_ID();
				$excerpt = wp_trim_words(get_the_excerpt(), $content_limit, '');
				$news_title = wp_trim_words(get_the_title(), $title_limit, '');
				$title = wp_trim_words(get_the_title(), $title_limit, '');
				$post_comment_num = number_format_i18n( get_comments_number() );
				$author = $query->post_author;
				?>
				<div class="media post-block post-block__mid m-b-xs-30 load-anim">
					<div class="media-body">
						<<?php echo esc_html( $settings['post_title_tag'] );?> class="sali-post-title hover-line">
								<a href="<?php the_permalink(); ?>"><?php echo esc_html( $title ); ?></a>
						</<?php echo esc_html( $settings['post_title_tag'] );?>>
						<?php if ( $settings['content_display'] == 'yes'){ ?>
							<P class="mid"><?php echo wp_kses_post( $excerpt ); ?></p>
						<?php } ?>
					</div>
				</div>
				<!-- End of .media -->
			<?php } ?>			
		<?php Helper::wp_reset_temp_query( $temp );
	 } ?>
	 <!-- End of .media -->
		<div class="sali-scroll-up-down">
			<a href="#" class="sali-post-scroll-down"></a>
			<a href="#" class="sali-post-scroll-up"></a>
		</div>
	</div>
</div>