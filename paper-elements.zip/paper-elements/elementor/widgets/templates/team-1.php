<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */


$themepfix = SALI_FIX_PRFX;
$thumb_size = "sali-size-md";

$args = array(
    'post_type' => "team",
    'posts_per_page' => $settings['number'],
    'offset' => $settings['offset'],
    'orderby' => $settings['orderby'],
);
switch ($settings['orderby']) {
    case 'title':
    case 'menu_order':
        $args['order'] = 'ASC';
        break;
}
$query = new WP_Query($args);
$col_class = "col-lg-{$settings['col_lg']} col-md-{$settings['col_md']} col-sm-{$settings['col_sm']}";


$temp = Helper::wp_set_temp_query($query);
?>
<div class="sali-team-grid-wrapper">
    <div class="row">
        <?php if ($query->have_posts()) : ?>
            <?php while ($query->have_posts()) : $query->the_post(); ?>
                <?php
                $id = get_the_id();
                $designation = get_post_meta($id, "{$themepfix}_team_designation", true);
                $sali_author_twitter = get_post_meta($id, $themepfix . '_twitter', true);
                $sali_author_facebook = get_post_meta($id, $themepfix . '_facebook', true);
                $sali_author_linkedin = get_post_meta($id, $themepfix . '_linkedin', true);
                $sali_author_pinterest = get_post_meta($id, $themepfix . '_pinterest', true);
                $sali_author_designation = get_post_meta($id, $themepfix . '_author_designation', true);
                ?>
                <div class="<?php echo esc_attr($col_class); ?>">
                    <div class="sali-team-block m-b-xs-30">
                        <?php
                        if (has_post_thumbnail()) { ?>
                            <a href="<?php the_permalink(); ?>" class="d-block img-container">
                                <?php the_post_thumbnail($thumb_size); ?>
                            </a>
                        <?php } ?>
                        <div class="sali-team-inner-content text-center">
                            <h3 class="sali-member-title hover-line"><a
                                        href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <?php if ($designation && $settings['designation_display'] == 'yes'): ?>
                                <div class="sali-designation"><?php echo esc_html($designation); ?></div>
                            <?php endif; ?>
                        </div>
                        <!-- End of .sali-team-inner-content -->
                        <?php if ($settings['social_display'] == 'yes'): ?>
                            <div class="sali-team-share-wrapper">
                                <ul class="social-share social-share__with-bg social-share__with-bg-white social-share__vertical">
                                    <?php if (!empty($sali_author_facebook)) { ?>
                                        <li><a href="<?php echo esc_attr($sali_author_facebook); ?>">
                                            <i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                                        </li><?php } ?>
                                    <?php if (!empty($sali_author_twitter)) { ?>
                                        <li><a href="<?php echo esc_attr($sali_author_twitter); ?>"><i
                                                    class="fab fa-twitter" aria-hidden="true"></i></a>
                                        </li><?php } ?>
                                    <?php if (!empty($sali_author_linkedin)) { ?>
                                        <li><a href="<?php echo esc_attr($sali_author_linkedin); ?>"><i
                                                    class="fab fa-linkedin-in" aria-hidden="true"></i></a>
                                        </li><?php } ?>
                                    <?php if (!empty($sali_author_pinterest)) { ?>
                                        <li><a href="<?php echo esc_attr($sali_author_pinterest); ?>"><i
                                                    class="fab fa-pinterest-p" aria-hidden="true"></i></a>
                                        </li><?php } ?>
                                </ul>
                                <!-- End of .social-share -->
                            </div>
                        <?php endif ?>
                        <!-- End of .sali-team-share-wrapper -->
                    </div>
                    <!-- End of .team-block -->
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
        <?php Helper::wp_reset_temp_query($temp); ?>
    </div>
</div>
