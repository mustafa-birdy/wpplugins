<?php 
	$themepfix = SALI_FIX_PRFX;
	$sali_image_size  = "sali-size-modern-slider-2";
	$paper_options 	= Helper::sali_get_options();	


	$post_sorting = $settings['post_sorting'];
	$post_ordering = $settings['post_ordering'];
	$title_limit = $settings['post_title_length'];
    // number
    $number_of_post = $settings['number_of_post'];
    $offset = $settings['offset'];
    $p_ids = array();

    // build up the array
    if ( !empty($settings['posts_not_in'])){
        foreach ( $settings['posts_not_in'] as $p_idsn ) {
            $p_ids[] = $p_idsn;
        }
    }
	$cat_single_list = $settings['cat_single_list'];
	$args = array(
		'category_name'  => !empty($settings['cat_single_list']) && is_array($settings['cat_single_list']) ? implode(',', $settings['cat_single_list']) : '',
		'post_status' => 'publish',
		'order' => $post_ordering,
		'posts_per_page' => $number_of_post,		
		'offset' => $offset,
		'post__not_in'   => $p_ids,
        'ignore_sticky_posts' => 1,
	);			
	if ( $post_sorting == 'view' ) {
		$args['orderby']  = 'meta_value_num';
		$args['meta_key'] = 'sali_views';
	} else {
		$args['orderby'] = $post_sorting;
	}
	$query = new WP_Query( $args );		
	$temp = Helper::wp_set_temp_query( $query );


if ($query->have_posts()) {
?>
<div class="banner banner__home-with-slider banner__home-with-slider-two grad-bg">
	<div class="sali-shape-circle shape-loaded"></div>
	<div class="sali-shape-circle__two shape-loaded"></div>
	<div class="container">
		<div class="row">
			<div class="col-xl-5">
				<div class="banner-slider-container banner-slider-container-two">
					<div id="sync2" class="slick-slider slick-slider-for" data-slick-nav="true">

						<?php 
						while ( $query->have_posts() ) { $query->the_post(); 
						$post_id 	= get_the_ID();
						$title 		= wp_trim_words(get_the_title(), $title_limit, '');
						$author 	= $query->post_author;
						?>

						<div class="item">
							<!-- End of .post-metas -->
							<?php if ('yes' === $settings['post_author'] || 'yes' === $settings['post_date']): ?>
								<div class="post-metas home-banner-post-metas m-b-xs-20">
									<ul class="list-inline">
										<?php if ('yes' === $settings['post_author']): ?>
											<li class="m-r-xs-20">
                                                <a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID', $author))) ?>" class="d-flex align-items-center">
                                                    <?php
                                                    $args = array( 'class' => 'm-r-xs-20 rounded-circle' );
                                                    echo get_avatar( get_the_author_meta( 'ID' ), 105, '', '', $args ); ?>
                                                    <span><?php echo get_the_author_meta('display_name', $author); ?></span>
                                                </a>
											</li>
										<?php endif ?>
										<?php if ( 'yes' === $settings['post_date'] ) { ?>
											<li><i class="separator-line m-r-xs-20"></i><?php echo get_the_time(get_option('date_format')); ?></li>
										<?php } ?>
									</ul>
								</div>
							<!-- End of .post-metas -->
							<?php endif ?>

							<?php 
							$slider_title = '<'. $settings['post_title_tag'] .' class="page-title m-b-xs-40 hover-line"><a href="'. get_the_permalink() .'">' .  $title .'</a></'.  $settings['post_title_tag'] .'>';
							echo wp_kses_post($slider_title);
							?>
							<?php if ( $settings['sali_post_read_more_button_show'] && !empty( $settings['sali_post_read_more_button_text'] ) || $settings['sali_post_modern_slider_all_post_button'] && !empty( $settings['sali_post_modern_slider_all_post_button_text'] ) ): ?>
								<div class="btn-group">
									<?php if ( $settings['sali_post_read_more_button_show'] && !empty( $settings['sali_post_read_more_button_text'] )): ?>
										<a href="<?php the_permalink(); ?>" class="btn btn-primary m-r-xs-30"><?php echo esc_html( $settings['sali_post_read_more_button_text'] ) ?></a>
									<?php endif ?>
									<?php 
									$attr = '';
									if ( '2' == $settings['sali_post_modern_slider_all_post_button_type'] ) {
									    $attr  = 'href="' . get_permalink( get_page_by_path( $settings['sali_post_modern_slider_all_post_button_page_link'] ) ) . '"';

									} else {
									    if ( !empty( $settings['sali_post_modern_slider_all_post_button_custom_link']['url'] ) ) {
									        $attr  = 'href="' . esc_url($settings['sali_post_modern_slider_all_post_button_custom_link']['url']) . '"';
									        $attr .= !empty( $settings['sali_post_modern_slider_all_post_button_custom_link']['is_external'] ) ? ' target="_blank"' : '';
									        $attr .= !empty( $settings['sali_post_modern_slider_all_post_button_custom_link']['nofollow'] ) ? ' rel="nofollow"' : ''; 
									    }
									}
									if ( $settings['sali_post_modern_slider_all_post_button'] && !empty( $settings['sali_post_modern_slider_all_post_button_text'] ) ) {
										$sali_post_modern_slider_all_post_button = '<a class="btn-link btn-link__mixed" '. $attr .'>' . $settings['sali_post_modern_slider_all_post_button_text'] . '</a>';
										echo wp_kses_post($sali_post_modern_slider_all_post_button);
									}
									?>
								</div>
							<?php endif ?>
						</div>
						<?php } ?>
						<?php Helper::wp_reset_temp_query( $temp ); ?>

						
					</div>
					<!-- End of .owl-carousel -->
				</div>
				<!-- End of .banner-slider-container -->
			</div>
			<!-- End of .col-lg-6 -->
		</div>
		<!-- End of .row -->

		<div class="banner-slider-container-synced banner-slider-container-synced__two">
			<div id="sync1" class="slick-slider slick-slider-nav" data-slick-loop="true" data-slick-dots="false"
				data-slick-items="2" data-slick-center="true" data-slick-autowidth="true">

				<?php 
				while ( $query->have_posts() ) { $query->the_post(); 
				$post_id 	= get_the_ID();
				$title 		= wp_trim_words(get_the_title(), $title_limit, '');
				$author 	= $query->post_author;
				// Image
				$image_id 			= get_post_thumbnail_id();
				$image_alt 			= get_post_meta($image_id, '_wp_attachment_image_alt', TRUE);	
				$the_post_thumbnail = Helper::generate_thumbnail_image( $post_id, $sali_image_size);
				// End image	
				?>
				<div class="item">
					<img src="<?php echo esc_url($the_post_thumbnail); ?>" alt="<?php echo esc_html($image_alt); ?>">
				</div>
				<?php } ?>
				<?php Helper::wp_reset_temp_query( $temp ); ?>
			</div>
			<!-- End of .owl-carousel -->
		</div>
		<!-- End of .banner-slider-container-synced -->

		<div class="banner-share-slider-container banner-share-slider-container__two">
			<div class="slick-slider banner-share-slider">
				<?php while ( $query->have_posts() ) { $query->the_post();  ?>
					<?php if ( function_exists( 'shared_counts' ) && $settings['post_shares'] ): ?>
						<div class="item">
							<div class="banner-shares slick-banner-shares">
								<div class="toggle-shares"><?php esc_html_e('Shares', 'paper-elements'); ?> <span>+</span></div>
								<div class="social-share-wrapper">
									<?php shared_counts()->front->display( $location = 'modern-slider modern-slider-2', $echo = true, $style = 'icon' ) ?>
								</div>
								<!-- End of .social-share-wrapper -->
							</div>
							<!-- End of .banner-shares -->
						</div>
					<?php endif ?>
				<?php } ?>
				<?php Helper::wp_reset_temp_query( $temp ); ?>
			</div>
			<!-- End of .owl-carousel -->
		</div>
	</div>
	<!-- End of .container -->
</div>
<!-- End of .banner -->
<?php
}