<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */
$themepfix = SALI_FIX_PRFX;
$thumb_size  = "sali-size-md";
$show_count 		  	= isset($settings['show_count']) ? $settings['show_count'] : false;
$hide_empty_category  	= isset($settings['hide_empty_category']) ? $settings['hide_empty_category'] : false;
$orderby  				= isset($settings['orderby']) ? $settings['orderby'] : 'name';
$order  				= isset($settings['order']) ? $settings['order'] : 'ASC';
$catsArray = $settings['category_lists'];
$categories = get_terms( array(
    'taxonomy' 			=> 'category',
     'hide_empty' 		=> $hide_empty_category,
    'slug'				=> $catsArray,    
    'orderby'           => $orderby,
    'order'             => $order,
  ) );
?>

<div class="sali-banner-cat-counter_slider">				
	<div class="sali-content_slider">
		<div class="category-list-wrapper_slider">
		<div class="owl-wrap sali-nav-control-auto">
			<div class="sali-paper-carousel owl-carousel" data-carousel-options="<?php echo esc_attr( $settings['carousel_data']);?>">
			<?php 			
			foreach( $categories as $category ):						
				$category_background_image 	= get_term_meta( $category->term_id, 'sali_category_image', true );
				$category_background_color 	= get_term_meta( $category->term_id, 'sali_category_color', true );	
				if ($category_background_image) {
				$bg = 'style="background-image: url('.$category_background_image.')"';
				$has_overlay = 'overlay';
				} elseif($category_background_color) {
				$bg = 'style="background-color: '.$category_background_color.'"';
				$has_overlay = '';
				} else {
				$bg = "";
				$has_overlay = '';
			} ?>

				<div class="category-list_slider perfect-square">
					<a href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>" class="list-inner_slider" <?php echo saliescap($bg); ?>>
				<div class="post-info-wrapper_slider <?php echo saliescap($has_overlay); ?>"> 
				<?php if ( $show_count): ?>
					<div class="counter-inner_slider"><span class="counter"><?php echo wp_kses_post($category->count); ?></span>+</div>
				<?php endif ?>							
				<?php if ( !empty($category->name) ): ?>
					<h4 class="cat-title_slider"><?php echo esc_html($category->name); ?></h4>
				<?php endif ?>
				</div>						
			</a>
						
				</div>			
			<?php  endforeach; ?>	
			</div>
			</div>
		</div>
	</div>
			
</div>

