<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;


if (!defined('ABSPATH')) exit; // Exit if accessed directly
class sali_post_masonry extends Widget_Base
{

    public $sali_name;
    public $sali_base;
    public $sali_category;
    public $sali_icon;
    public $sali_translate;

    public function __construct($settings = [], $args = null)
    {
        $this->sali_category = SALI_ELEMENTS_PRFX . '-widgets'; // Category /@dev
        $this->sali_icon = 'eicon-posts-masonry';
        $this->sali_name = esc_html__('Paper Posts Masonry', 'paper-elements');
        $this->sali_base = 'salinews-post-masonry';
        $this->sali_translate = array(
            'cols' => array(
                '12' => esc_html__('1 Col', 'paper-elements'),
                '6' => esc_html__('2 Col', 'paper-elements'),
                '4' => esc_html__('3 Col', 'paper-elements'),
                '3' => esc_html__('4 Col', 'paper-elements'),
            ),
        );
        parent::__construct($settings, $args);
    }

    public function get_name()
    {
        return $this->sali_base;
    }

    public function get_title()
    {
        return $this->sali_name;
    }

    public function get_icon()
    {
        return $this->sali_icon;
    }

    public function get_categories()
    {
        return array($this->sali_category);
    }

    public function sali_fields()
    {
        $categories = get_categories();
        foreach ($categories as $category) {
            $category_dropdown[$category->slug] = $category->name;
        }
        $fields = array(
            array(
                'mode' => 'section_start',
                'id' => 'sec_title',
                'label' => esc_html__('Section Title & Button', 'paper-elements'),
            ),
            array(
                'label' => esc_html__('Section Title Show', 'paper-elements'),
                'type' => Controls_Manager::SWITCHER,
                'id' => 'has_sec_title',
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'return_value' => 'yes',
                'default' => 'no',
            ),
            array(
                'type' => Controls_Manager::CHOOSE,
                'id' => 'sec_title_tag',
                'label' => esc_html__('Title HTML Tag', 'paper-elements'),
                'options' => array(
                    'h1' => [
                        'title' => esc_html__('H1', 'paper-elements'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'paper-elements'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'paper-elements'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'paper-elements'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'paper-elements'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'paper-elements'),
                        'icon' => 'eicon-editor-h6'
                    ],
                    'div' => [
                        'title' => esc_html__('div', 'paper-elements'),
                        'icon' => 'eicon-font'
                    ]
                ),
                'default' => 'h2',
                'label_block' => true,
                'toggle' => false,
                'condition' => array('has_sec_title' => array('yes')),
            ),
            array(
                'type' => Controls_Manager::TEXTAREA,
                'id' => 'title',
                'label' => esc_html__('Title', 'paper-elements'),
                'default' => 'News',
                'condition' => array('has_sec_title' => array('yes')),
            ),
            array(
                'mode' => 'group',
                'type' => Group_Control_Typography::get_type(),
                'name' => 'section_title_typography',
                'label' => esc_html__('Typography', 'paper-elements'),
                'selector' => '{{WRAPPER}} .sali-title',
                'condition' => array('has_sec_title' => array('yes')),
            ),

            array(
                'type' => Controls_Manager::COLOR,
                'id' => 'title_color',
                'label' => esc_html__('Title Color', 'paper-elements'),
                'selectors' => array(
                    '{{WRAPPER}} .sali-title' => 'color: {{VALUE}}',
                ),
                'condition' => array('has_sec_title' => array('yes')),
            ),
            array(
                'id' => 'hrt-1',
                'type' => Controls_Manager::DIVIDER,
                'style' => 'thick',
            ),
            array(
                'label' => esc_html__('Right Link Button Show', 'paper-elements'),
                'type' => Controls_Manager::SWITCHER,
                'id' => 'has_sec_right_button',
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'return_value' => 'yes',
                'default' => 'no',
            ),
            array(
                'id' => 'sali_post_masonry_link_text',
                'label' => esc_html__('Button Text', 'paper-elements'),
                'type' => Controls_Manager::TEXT,
                'default' => 'View All Post',
                'title' => esc_html__('Enter button text', 'paper-elements'),
                'condition' => array('has_sec_right_button' => array('yes')),
            ),
            array(
                'id' => 'sali_post_masonry_link_type',
                'label' => esc_html__('Button Link Type', 'paper-elements'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__( 'Custom Link', 'paper-elements' ),
                    '2' => esc_html__( 'Internal Page', 'paper-elements' ),
                    '3' => esc_html__( 'News Category', 'paper-elements' ),
                    '4' => esc_html__( 'Post Format', 'paper-elements' ),
                ],
                'default' => '1',
                'condition' => array('has_sec_right_button' => array('yes')),
            ),
            array(
                'id' => 'sali_post_masonry_custom_link',
                'label' => esc_html__('Button link', 'paper-elements'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'paper-elements'),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'condition' => [
                    'sali_post_masonry_link_type' => '1',
                    'has_sec_right_button' => array('yes')
                ]
            ),
            array(
                'id' => 'sali_post_masonry_page_link',
                'label' => esc_html__('Select Button Page', 'paper-elements'),
                'type' => Controls_Manager::SELECT2,
                'options' => sali_get_all_pages(),
                'condition' => [
                    'sali_post_masonry_link_type' => '2',
                    'has_sec_right_button' => array('yes')
                ]
            ),
             array(
                    'id'            => 'sali_post_grid_cat_link',
                    'label'         => esc_html__( 'Select Category', 'paper-elements' ),
                    'type'          => Controls_Manager::SELECT2,                    
                    'options'   => $category_dropdown,                 
                       'condition' => array( 
                            'sali_post_masonry_link_type' => array( '3' ),
                            'has_sec_right_button' => array( 'yes' ),
                         ),
                ),
             array(
                    'id'            => 'sali_post_grid_format_link',
                    'label'         => esc_html__( 'Select Post Format', 'paper-elements' ),
                    'type'          => Controls_Manager::SELECT2, 
                    'options'       => array(
                        'aside'     => esc_html__( 'Aside', 'paper-elements' ),
                        'gallery'   => esc_html__( 'Gallery', 'paper-elements' ),
                        'status'    => esc_html__( 'Status', 'paper-elements' ),
                        'video'     => esc_html__( 'video', 'paper-elements' ),
                        'audio'     => esc_html__( 'Audio', 'paper-elements' ),
                        ),  
                   'condition' => array( 
                            'sali_post_masonry_link_type' => array( '4' ),
                            'has_sec_right_button' => array( 'yes' ),
                         ),
                ),       

            array(
                'mode' => 'section_end',
            ),
            array(
                'mode' => 'section_start',
                'id' => 'sec_general',
                'label' => esc_html__('Layout', 'paper-elements'),
            ),
            array(
                'type' => Controls_Manager::SELECT2,
                'id' => 'style',
                'label' => esc_html__('Style', 'paper-elements'),
                'options' => array(
                    'style1' => esc_html__('Style 1', 'paper-elements'),
                    'style2' => esc_html__('Style 2', 'paper-elements'),
                ),
                'default' => 'style1',
            ),
            array(
                'type' => Controls_Manager::CHOOSE,
                'id' => 'content_alignment',
                'label' => esc_html__('Content Alignment', 'paper-elements'),
                'options' => [
                    'text-left' => [
                        'title' => esc_html__( 'Left', 'paper-elements' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'text-center' => [
                        'title' => esc_html__( 'Center', 'paper-elements' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'text-right' => [
                        'title' => esc_html__( 'Right', 'paper-elements' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'toggle' => true,
            ),
            array(
                'mode' => 'section_end',
            ),
            array(
                'mode' => 'section_start',
                'id' => 'sec_query',
                'label' => esc_html__('Query', 'paper-elements'),
            ),
            array(
                'type' => Controls_Manager::SELECT2,
                'id' => 'post_sorting',
                'label' => esc_html__('Post Sorting', 'paper-elements'),
                'options' => array(
                    'recent' => esc_html__('Recent Post', 'paper-elements'),
                    'rand' => esc_html__('Random Post', 'paper-elements'),
                    'modified' => esc_html__('Last Modified Post', 'paper-elements'),
                    'comment_count' => esc_html__('Most commented Post', 'paper-elements'),
                    'view' => esc_html__('Most viewed Post', 'paper-elements'),
                ),
                'default' => 'recent',
            ),
            /* Post Order */
            array(
                'type' => Controls_Manager::SELECT2,
                'id' => 'post_ordering',
                'label' => esc_html__('Post Ordering', 'paper-elements'),
                'options' => array(
                    'DESC' => esc_html__('Desecending', 'paper-elements'),
                    'ASC' => esc_html__('Ascending', 'paper-elements'),
                ),
                'default' => 'DESC',
            ),
            array(
                'type' => Controls_Manager::SELECT2,
                'id' => 'cat_single_list',
                'label' => esc_html__('Categories', 'paper-elements'),
                'options' => $category_dropdown,
                'default' => '0',
                'multiple' => true,

            ),
            array(
                'type' => Controls_Manager::NUMBER,
                'id' => 'number_of_post',
                'label' => esc_html__('Number of Post', 'paper-elements'),
                'default' => '10',
            ),
            array(
                'type' => Controls_Manager::NUMBER,
                'id' => 'offset',
                'label' => esc_html__('Offset', 'paper-elements'),
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'posts_not_in',
                'label'   => __( 'Select The Posts that will not display', 'paper-elements' ),
                'label_block'   => true,
                'multiple'      => true,
                'separator'     => 'before',
                'options'       => sali_post_name(),
            ),
            array(
                'mode' => 'section_end',
            ),
            array(
                'mode' => 'section_start',
                'id' => 'sec_meta_query',
                'label' => esc_html__('Display Options', 'paper-elements'),
            ),
            array(
                'type' => Controls_Manager::CHOOSE,
                'id' => 'post_title_tag',
                'label' => esc_html__('Title HTML Tag', 'paper-elements'),
                'options' => array(
                    'h1' => [
                        'title' => esc_html__('H1', 'paper-elements'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'paper-elements'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'paper-elements'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'paper-elements'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'paper-elements'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'paper-elements'),
                        'icon' => 'eicon-editor-h6'
                    ],
                    'div' => [
                        'title' => esc_html__('div', 'paper-elements'),
                        'icon' => 'eicon-font'
                    ]
                ),
                'default' => 'h3',
                'toggle' => false,
            ),
            array(
                'type' => Controls_Manager::NUMBER,
                'id' => 'post_title_length',
                'label' => esc_html__('Post Title Length', 'paper-elements'),
                'default' => '10',
            ),
            array(
                'mode' => 'group',
                'type' => Group_Control_Typography::get_type(),
                'name' => 'post_title_typography',
                'label' => esc_html__('Post Title Typography', 'paper-elements'),
                'selector' => '{{WRAPPER}} .sali-post-title',
            ),
            array(
                'id' => 'hrt-2',
                'type' => Controls_Manager::DIVIDER,
                'style' => 'thick',
            ),
            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'content_display',
                'label' => esc_html__('Show content Display', 'paper-elements'),
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'default' => 'yes',
                'return_value' => 'yes',
            ),
            array(
                'type' => Controls_Manager::NUMBER,
                'id' => 'post_content_length',
                'label' => esc_html__('Post Excerpt Length', 'paper-elements'),
                'default' => '20',
                'condition' => array('content_display' => array('yes')),
            ),

            array(
                'id' => 'hr-masonry-1',
                'type' => Controls_Manager::DIVIDER,
                'style' => 'thick',
            ),
            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'cat_display',
                'label' => esc_html__('Category Name Display', 'paper-elements'),
                'label_on' => esc_html__('On', 'paper-elements'),
                'label_off' => esc_html__('Off', 'paper-elements'),
                'default' => 'yes',
                'return_value' => 'yes',
            ),

            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'post_date',
                'label' => esc_html__('Display Post Date', 'paper-elements'),
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'default' => 'no',
                'return_value' => 'yes',
            ),

            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'post_author',
                'label' => esc_html__('Display Author Name', 'paper-elements'),
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'default' => 'no',
            ),

            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'post_update_date',
                'label' => esc_html__('Display Update Date', 'paper-elements'),
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'default' => 'no',
            ),
            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'post_view',
                'label' => esc_html__('Display post view', 'paper-elements'),
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'default' => 'no',
            ),
            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'post_shares',
                'label' => esc_html__('Display post shares', 'paper-elements'),
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'default' => 'no',
            ),

            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'post_comment',
                'label' => esc_html__('Display Comment Number', 'paper-elements'),
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'default' => 'no',
            ),

            /* Hide Thumbnail */
            array(
                'id' => 'hr-masonry-11',
                'type' => Controls_Manager::DIVIDER,
                'style' => 'thick',
            ),
            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'show_post_thumb',
                'label' => esc_html__('Display Post Thumbnail', 'paper-elements'),
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('hide', 'paper-elements'),
                'default' => 'yes',
            ),

            array(
                'type' => Controls_Manager::SWITCHER,
                'id' => 'pagination_display',
                'label' => esc_html__('Pagination ', 'paper-elements'),
                'label_on' => esc_html__('Show', 'paper-elements'),
                'label_off' => esc_html__('Hide', 'paper-elements'),
                'default' => 'no',
            ),

            array(
                'mode' => 'section_end',
            ),

            // Responsive Columns
            array(
                'mode' => 'section_start',
                'id' => 'sec_responsive',
                'label' => __('Responsive Columns', 'paper-elements'),
            ),
            array(
                'type' => Controls_Manager::SELECT2,
                'id' => 'col_lg',
                'label' => __('Desktops: > 1199px', 'paper-elements'),
                'options' => $this->sali_translate['cols'],
                'default' => '4',
            ),
            array(
                'type' => Controls_Manager::SELECT2,
                'id' => 'col_md',
                'label' => __('Desktops: > 991px', 'paper-elements'),
                'options' => $this->sali_translate['cols'],
                'default' => '6',
            ),
            array(
                'type' => Controls_Manager::SELECT2,
                'id' => 'col_sm',
                'label' => __('Tablets: > 767px', 'paper-elements'),
                'options' => $this->sali_translate['cols'],
                'default' => '12',
            ),
            array(
                'mode' => 'section_end',
            ),

        );
        return $fields;

    }

    protected function _register_controls()
    {
        $fields = $this->sali_fields();
        foreach ($fields as $field) {
            if (isset($field['mode']) && $field['mode'] == 'section_start') {
                $id = $field['id'];
                unset($field['id']);
                unset($field['mode']);
                $this->start_controls_section($id, $field);
            } elseif (isset($field['mode']) && $field['mode'] == 'section_end') {
                $this->end_controls_section();
            } elseif (isset($field['mode']) && $field['mode'] == 'group') {
                $type = $field['type'];
                unset($field['mode']);
                unset($field['type']);
                $this->add_group_control($type, $field);
            } elseif (isset($field['mode']) && $field['mode'] == 'responsive') {
                $id = $field['id'];
                unset($field['id']);
                unset($field['mode']);
                $this->add_responsive_control($id, $field);
            } else {
                $id = $field['id'];
                unset($field['id']);
                $this->add_control($id, $field);
            }
        }
    }

    protected function render()
    {
        $settings = $this->get_settings();
        $template = 'post-masonry-1';
        return Sali_Elements_Helper::sali_element_template($template, $settings);
    }
}
