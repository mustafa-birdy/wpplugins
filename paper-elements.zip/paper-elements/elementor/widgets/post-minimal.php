<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class sali_post_minimal extends Widget_Base {

    public $sali_name;
    public $sali_base;
    public $sali_category;
    public $sali_icon;
    public $sali_translate;
    public function __construct( $settings = [], $args = null ) {
        $this->sali_category = SALI_ELEMENTS_PRFX . '-widgets'; // Category /@dev
        $this->sali_icon     = 'eicon-text';
        $this->sali_name = esc_html__( 'Paper Posts Minimal', 'paper-elements' );
        $this->sali_base = 'salinews-post-minimal';
        $this->sali_translate = array(
            'cols'  => array(
                '12' =>esc_html__( '1 Col', 'paper-elements' ),
                '6'  =>esc_html__( '2 Col', 'paper-elements' ),
                '4'  =>esc_html__( '3 Col', 'paper-elements' ),
                '3'  =>esc_html__( '4 Col', 'paper-elements' ),
                '2'  =>esc_html__( '6 Col', 'paper-elements' ),
            ),
        );
        parent::__construct( $settings, $args );
    }
    public function get_name() {
        return $this->sali_base;
    }
    public function get_title() {
        return $this->sali_name;
    }
    public function get_icon() {
        return $this->sali_icon;
    }
    public function get_categories() {
        return array( $this->sali_category );
    }
    public function sali_fields(){    
        $categories = get_categories();
        foreach ( $categories as $category ) {
            $category_dropdown[$category->slug] = $category->name;
        }     
        $fields = array(               
            array(
                'mode'    => 'section_start',
                'id'      => 'sec_query',
                'label'   => esc_html__( 'Query', 'paper-elements' ),
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'post_sorting',
                'label'   => esc_html__( 'Post Sorting', 'paper-elements' ),
                'options' => array(
                    'recent'        => esc_html__( 'Recent Post', 'paper-elements' ),
                    'rand'          => esc_html__( 'Random Post', 'paper-elements' ),
                    'modified'      => esc_html__( 'Last Modified Post', 'paper-elements' ),
                    'comment_count' => esc_html__( 'Most commented Post', 'paper-elements' ),
                    'view'          => esc_html__( 'Most viewed Post', 'paper-elements' ),
                ),
                'default' => 'recent',
            ),      
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'post_ordering',
                'label'   => esc_html__( 'Post Ordering', 'paper-elements' ),
                'options' => array(
                    'DESC'  => esc_html__( 'Desecending', 'paper-elements' ),
                    'ASC'   => esc_html__( 'Ascending', 'paper-elements' ),
                ),
                'default' => 'DESC',
            ),               
            array (
                'type'      => Controls_Manager::SELECT2,
                'id'        => 'cat_single_list',
                'label'     => esc_html__( 'Categories', 'paper-elements' ),
                'options'   => $category_dropdown,
                'default'   => '0',
                'multiple'  => true,
               
            ),          
            array(
                'type'    => Controls_Manager::NUMBER,
                'id'      => 'number_of_post',
                'label'   => esc_html__( 'Number of Post', 'paper-elements' ),
                'default' => '4',               
            ),
            array(
                'type' => Controls_Manager::NUMBER,
                'id' => 'offset',
                'label' => esc_html__('Offset', 'paper-elements'),
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'posts_not_in',
                'label'   => esc_html__( 'Select The Posts that will not display', 'paper-elements' ),
                'label_block'   => true,
                'multiple'      => true,
                'separator'     => 'before',
                'options'       => sali_post_name(),
            ),

        array(
                'mode' => 'section_end',
            ),
            array(
                'mode'    => 'section_start',
                'id'      => 'sec_meta_query',
                'label'   => esc_html__( 'Display Options', 'paper-elements' ),
            ),
            array(
                'type'    => Controls_Manager::CHOOSE,
                'id'      => 'post_title_tag',
                'label'   => esc_html__( 'Title HTML Tag', 'paper-elements' ),
                'options' => array(
                    'h1'  => [
                        'title' => esc_html__( 'H1', 'paper-elements' ),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2'  => [
                        'title' => esc_html__( 'H2', 'paper-elements' ),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3'  => [
                        'title' => esc_html__( 'H3', 'paper-elements' ),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4'  => [
                        'title' => esc_html__( 'H4', 'paper-elements' ),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5'  => [
                        'title' => esc_html__( 'H5', 'paper-elements' ),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6'  => [
                        'title' => esc_html__( 'H6', 'paper-elements' ),
                        'icon' => 'eicon-editor-h6'
                    ],
                    'div'  => [
                        'title' => esc_html__( 'div', 'paper-elements' ),
                        'icon' => 'eicon-font'
                    ]
                ),
                'default' => 'h3',
                'toggle' => false,
            ),
            array(
                'type'    => Controls_Manager::NUMBER,
                'id'      => 'post_title_length',
                'label'   => esc_html__( 'Post Title Length', 'paper-elements' ),
                'default' => '10',
            ),
             array( 
                    'mode'      => 'group',
                    'type'      => Group_Control_Typography::get_type(),
                    'name'      => 'post_title_typography',                
                    'label'     => esc_html__( 'Post Title Typography', 'paper-elements' ),
                    'selector'  => '{{WRAPPER}} .sali-post-title',
                ),
            array(
                'type'          => Controls_Manager::SWITCHER,
                'id'            => 'content_display',
                'label'         => esc_html__( 'Show content Display', 'paper-elements' ),
                'label_on'      => esc_html__( 'Show', 'paper-elements' ),
                'label_off'     => esc_html__( 'Hide', 'paper-elements' ),
                'default'       => 'yes',
                'return_value'  => 'yes',
            ),  
            array(
                'type'    => Controls_Manager::NUMBER,
                'id'      => 'post_content_length',
                'label'   => esc_html__( 'Post Excerpt Length', 'paper-elements' ),
                'default' => '20',
                'condition' => array( 'content_display' => array( 'yes' ) ),
            ),
            array(
                'mode' => 'section_end',
            ),
            
        );
        return $fields;

    }

protected function _register_controls() {
    $fields = $this->sali_fields();
    foreach ( $fields as $field ) {
      if ( isset( $field['mode'] ) && $field['mode'] == 'section_start' ) {
        $id = $field['id'];
        unset( $field['id'] );
        unset( $field['mode'] );
        $this->start_controls_section( $id, $field );
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'section_end' ) {
        $this->end_controls_section();
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'group' ) {
        $type = $field['type'];
        unset( $field['mode'] );
        unset( $field['type'] );
        $this->add_group_control( $type, $field );
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'responsive' ) {
        $id = $field['id'];
        unset( $field['id'] );
        unset( $field['mode'] );
        $this->add_responsive_control( $id, $field );
      }
      else {
        $id = $field['id'];
        unset( $field['id'] );
        $this->add_control( $id, $field );
      }
    }
}

protected function render() {
    $settings = $this->get_settings();     
    $template = 'post-minimal-1';
    return Sali_Elements_Helper::sali_element_template( $template, $settings );
    }
}
