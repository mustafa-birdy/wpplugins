<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */
use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class Team_Grid extends Widget_Base {
   
    public $sali_name;
    public $sali_base;
    public $sali_category;
    public $sali_icon;
    public $sali_translate;
    public function __construct( $settings = [], $args = null ) {
        
        $this->sali_category = SALI_ELEMENTS_PRFX . '-widgets'; // Category /@dev
        $this->sali_icon     = 'eicon-person';
        $this->sali_name = esc_html__( 'Paper Team Grid', 'paper-elements' );
        $this->sali_base = 'salinews-team-grid';
        	$this->sali_translate = array(
			'cols'  => array(
				'12' => esc_html__( '1 Col', 'paper-elements' ),
				'6'  => esc_html__( '2 Col', 'paper-elements' ),
				'4'  => esc_html__( '3 Col', 'paper-elements' ),
				'3'  => esc_html__( '4 Col', 'paper-elements' ),
				'2'  => esc_html__( '6 Col', 'paper-elements' ),
			),
		);
        parent::__construct( $settings, $args );
    }
    public function get_name() {
        return $this->sali_base;
    }
    public function get_title() {
        return $this->sali_name;
    }
    public function get_icon() {
        return $this->sali_icon;
    }
    public function get_categories() {
        return array( $this->sali_category );
    }
    public function sali_fields(){  
        $themepfix = SALI_FIX_PRFX;		
        $terms  = get_terms( array( 'taxonomy' => "{$themepfix}_team_category") );
        if ( $terms && !is_wp_error( $terms )) {
            foreach ( $terms as $term ) {
               $category_dropdown[$term->slug] = $term->name;
            }
            
        }
        $fields = array(
            array(
                'mode'    => 'section_start',
                'id'      => 'sec_query',
                'label'   => esc_html__( 'Query', 'paper-elements' ),
            ),
                       
            array(
                'type'    => Controls_Manager::NUMBER,
                'id'      => 'number',
                'label'   =>  esc_html__( 'Total number of items', 'paper-elements' ),
                'default' => -1,
                'description' => esc_html__( 'Write -1 to show all', 'paper-elements' ),
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'orderby',
                'label'   => esc_html__( 'Order By', 'paper-elements' ),
                'options' => array(
                    'date'        => esc_html__( 'Date (Recents comes first)', 'paper-elements' ),
                    'title'       => esc_html__( 'Title', 'paper-elements' ),
                    'menu_order'  => esc_html__( 'Custom Order (Available via Order field inside Page Attributes box)', 'paper-elements' ),
                ),
                'default' => 'date',
            ),
            array(
                'type' => Controls_Manager::NUMBER,
                'id' => 'offset',
                'label' => esc_html__('Offset', 'paper-elements'),
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'designation_display',
                'label'       => esc_html__( 'Designation Display', 'paper-elements' ),
                'label_on'    => esc_html__( 'On', 'paper-elements' ),
                'label_off'   => esc_html__( 'Off', 'paper-elements' ),
                'default'     => 'yes',
                'description' => esc_html__( 'Show or Hide Designation. Default: On', 'paper-elements' ),
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'social_display',
                'label'       => esc_html__( 'Social Media Display', 'paper-elements' ),
                'label_on'    => esc_html__( 'On', 'paper-elements' ),
                'label_off'   => esc_html__( 'Off', 'paper-elements' ),
                'default'     => 'yes',
                'description' => esc_html__( 'Show or Hide Social Medias. Default: On', 'paper-elements' ),
            ),
            array(
                'mode' => 'section_end',
            ),
            array(
                'mode'    => 'section_start',
                'id'      => 'sec_responsive',
                'label'   => esc_html__( 'Responsive Columns', 'paper-elements' ),
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'col_lg',
                'label'   => esc_html__( 'Desktops: > 1199px', 'paper-elements' ),
                'options' => $this->sali_translate['cols'],
                'default' => '4',
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'col_md',
                'label'   => esc_html__( 'Desktops: > 991px', 'paper-elements' ),
                'options' => $this->sali_translate['cols'],
                'default' => '6',
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'col_sm',
                'label'   => esc_html__( 'Tablets: > 767px', 'paper-elements' ),
                'options' => $this->sali_translate['cols'],
                'default' => '12',
            ),           
            array(
                'mode' => 'section_end',
            ),            
            
        );
        return $fields;
    }
     protected function _register_controls() {
        $fields = $this->sali_fields();
        foreach ( $fields as $field ) {
          if ( isset( $field['mode'] ) && $field['mode'] == 'section_start' ) {
            $id = $field['id'];
            unset( $field['id'] );
            unset( $field['mode'] );
            $this->start_controls_section( $id, $field );
          }
          elseif ( isset( $field['mode'] ) && $field['mode'] == 'section_end' ) {
            $this->end_controls_section();
          }
          elseif ( isset( $field['mode'] ) && $field['mode'] == 'group' ) {
            $type = $field['type'];
            unset( $field['mode'] );
            unset( $field['type'] );
            $this->add_group_control( $type, $field );
          }
          elseif ( isset( $field['mode'] ) && $field['mode'] == 'responsive' ) {
            $id = $field['id'];
            unset( $field['id'] );
            unset( $field['mode'] );
            $this->add_responsive_control( $id, $field );
          }
          else {
            $id = $field['id'];
            unset( $field['id'] );
            $this->add_control( $id, $field );
          }
        }
      }
	private function sali_scripts(){
		wp_enqueue_style(  'owl-carousel' );
		wp_enqueue_style(  'owl-theme-default' );
		wp_enqueue_script( 'owl-carousel' );
	}
    protected function render() {
        $settings = $this->get_settings(); 
        $template = 'team-1';
        return Sali_Elements_Helper::sali_element_template( $template, $settings );
    }
}
