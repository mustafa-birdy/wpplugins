<div class="section-title d-block">
    <h2 class="h3 sali-title m-b-xs-20">Send Us a Message</h2>
    <p>Your email address will not be published. <br> All the fields are required.</p>
</div>
<div class="sali-contact-form-wrapper sali-contact-form row no-gutters">
    <div class="form-group col-12">
        <label for="name">Name</label>[text* text-34 id:Name]
    </div>
    <div class="form-group col-12">
        <label for="phone">Phone</label>[tel tel-659 id:phone]
    </div>
    <div class="form-group col-12">
        <label for="email">Email</label>[email* email-593 id:email]
    </div>
    <div class="form-group col-12">
        <label for="message">Message</label>[textarea textarea-766 id:message x5]
    </div>
    <div class="col-12">
        <button class="btn btn-primary m-t-xs-0 m-t-lg-20">SUBMIT</button>
    </div>
</div>