<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class sali_post_modern_slider extends Widget_Base {
    public $sali_name;
    public $sali_base;
    public $sali_category;
    public $sali_icon;
    public $sali_translate;
    public function __construct( $settings = [], $args = null ) {
        $this->sali_category = SALI_ELEMENTS_PRFX . '-widgets'; // Category /@dev
        $this->sali_icon     = 'eicon-post-slider';
        $this->sali_name = esc_html__( 'Paper Posts Modern Slider', 'paper-elements' );
        $this->sali_base = 'salinews-post-modern-slider';
        parent::__construct( $settings, $args );
    }
    public function get_name() {
        return $this->sali_base;
    }
    public function get_title() {
        return $this->sali_name;
    }
    public function get_icon() {
        return $this->sali_icon;
    }
    public function get_categories() {
        return array( $this->sali_category );
    }
    public function sali_fields(){    
        $categories = get_categories();
        foreach ( $categories as $category ) {
            $category_dropdown[$category->slug] = $category->name;
        }             
        $fields = array(          
            array(
                'mode'    => 'section_start',
                'id'      => 'sec_layout',
                'label'   => esc_html__( 'Layout', 'paper-elements' ),
            ),                 
                array(
                    'type'    => Controls_Manager::SELECT2,
                    'id'      => 'style',
                    'label'   => esc_html__( 'List Type', 'paper-elements' ),
                    'options' => array(
                        'style1' => esc_html__( 'Layout 1', 'paper-elements' ),
                        'style2' => esc_html__( 'Layout 2', 'paper-elements' ),
                    ),
                    'default' => 'style1',
                ),
                array(
                    'mode'      => 'group',
                    'type'      => Group_Control_Background::get_type(),
                    'types'     => array(
                        'classic',
                    ),
                    'name'      => 'modern_slider_one_background',
                    'label'     => esc_html__( 'Background Color', 'paper-elements' ),
                    'selector'  => '{{WRAPPER}} .banner__home-with-slider-overlay',
                    'condition' => array(
                        'style' => array( 'style1' ),
                    ),
                ),
                array( 
                    'mode'      => 'group',
                    'type'      => Group_Control_Background::get_type(),
                    'types'     => array(  
                        'gradient', 
                    ),
                    'name'      => 'modern_slider_two_background',                
                    'label'     => esc_html__( 'Background Gradient Color', 'paper-elements' ),
                    'selector'  => '{{WRAPPER}} .banner.banner__home-with-slider.banner__home-with-slider-two.grad-bg',
                    'condition' => array(
                        'style' => array( 'style2' ),
                    ),
                ),

                array(
                    'type'        => Controls_Manager::SWITCHER,
                    'id'          => 'sali_post_read_more_button_show',
                    'label'       => __( 'Read More Button', 'paper-elements' ),
                    'label_on'    => __( 'Show', 'paper-elements' ),
                    'label_off'   => __( 'Hide', 'paper-elements' ),
                    'default'     => 'yes',
                    'return_value' => 'yes',
                    'separator' => 'before',
                ), 
                array(                    
                    'id'        => 'sali_post_read_more_button_text',
                    'label'     => esc_html__( 'Read More Button Text', 'paper-elements' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => 'READ MORE',
                    'title'     => esc_html__( 'Enter button text', 'paper-elements' ), 
                    'label_block' => true,
                    'condition' => array( 
                        'sali_post_read_more_button_show' => array( 'yes' ),                            
                    ), 
                ),
                array(
                    'type'        => Controls_Manager::SWITCHER,
                    'id'          => 'sali_post_modern_slider_all_post_button',
                    'label'       => __( 'All News Button', 'paper-elements' ),
                    'label_on'    => __( 'Show', 'paper-elements' ),
                    'label_off'   => __( 'Hide', 'paper-elements' ),
                    'default'     => 'yes',
                    'return_value' => 'yes',
                    'separator' => 'before',
                ), 
                array(                    
                    'id'        => 'sali_post_modern_slider_all_post_button_text',
                    'label'     => esc_html__( 'All News Button Text', 'paper-elements' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => 'ALL CURRENT NEWS',
                    'title'     => esc_html__( 'Enter all news button text', 'paper-elements' ), 
                    'label_block' => true,
                    'condition' => array( 
                        'sali_post_modern_slider_all_post_button' => array( 'yes' ),                            
                    ), 
                ),
                array(
                    'id'        => 'sali_post_modern_slider_all_post_button_type',
                    'label'     => esc_html__( 'Button Link Type', 'paper-elements' ),
                    'type'      => Controls_Manager::SELECT,
                  
                    'options' => array(
                        '1' => esc_html__( 'Custom Link', 'paper-elements' ),
                        '2' => esc_html__( 'Internal Page', 'paper-elements' ),
                       
                    ),
                    'default'   => '1',   
                    'condition' => array( 
                        'sali_post_modern_slider_all_post_button' => array( 'yes' ),                            
                    ),                  
                ),

                array(
                    'type'    => Controls_Manager::URL,
                    'id'      => 'sali_post_modern_slider_all_post_button_custom_link',
                    'label'   => __( 'Button URL', 'paper-elements' ),
                    'placeholder' => 'https://your-link.com',
                    'default' => [
                        'url' => '#',
                        'is_external' => false,
                        'nofollow' => false,
                    ],
                    'condition' => array( 
                        'sali_post_modern_slider_all_post_button_type' => array( '1' ),                            
                        'sali_post_modern_slider_all_post_button' => array( 'yes' ),                            
                     ),
                ),                
                array(
                    'id'            => 'sali_post_modern_slider_all_post_button_page_link',
                    'label'         => esc_html__( 'Select Button Page', 'paper-elements' ),
                    'type'          => Controls_Manager::SELECT2,                    
                    'options'       => sali_get_all_pages(),                   
                       'condition' => array( 
                            'sali_post_modern_slider_all_post_button_type' => array( '2' ),   
                            'sali_post_modern_slider_all_post_button' => array( 'yes' ),                         
                        ),
                ),
            array(
                'mode' => 'section_end',
            ),

            array(
                'mode'    => 'section_start',
                'id'      => 'sec_query',
                'label'   => __( 'Query', 'paper-elements' ),
            ),
            array (
                'type'      => Controls_Manager::SELECT2,
                'id'        => 'cat_single_list',
                'label'     => __( 'Categories', 'paper-elements' ),
                'options'   => $category_dropdown,
                'default'   => '0',
                'multiple'  => true,
               
            ), 
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'post_sorting',
                'label'   => __( 'Post Sorting', 'paper-elements' ),
                'options' => array(
                    'recent'        => __( 'Recent Post', 'paper-elements' ),
                    'rand'          => __( 'Random Post', 'paper-elements' ),
                    'modified'      => __( 'Last Modified Post', 'paper-elements' ),
                    'comment_count' => __( 'Most commented Post', 'paper-elements' ),
                    'view'          => __( 'Most viewed Post', 'paper-elements' ),
                ),
                'default' => 'recent',
            ),
                  
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'post_ordering',
                'label'   => __( 'Post Ordering', 'paper-elements' ),
                'options' => array(
                    'DESC'  => __( 'Desecending', 'paper-elements' ),
                    'ASC'   => __( 'Ascending', 'paper-elements' ),
                ),
                'default' => 'DESC',
            ),          
                  
            array(
                'type'    => Controls_Manager::NUMBER,
                'id'      => 'number_of_post',
                'label'   => __( 'Number of Post', 'paper-elements' ),
                'default' => '4',               
            ),
            array(
                'type' => Controls_Manager::NUMBER,
                'id' => 'offset',
                'label' => esc_html__('Offset', 'paper-elements'),
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'posts_not_in',
                'label'   => esc_html__( 'Select The Posts that will not display', 'paper-elements' ),
                'label_block'   => true,
                'multiple'      => true,
                'separator'     => 'before',
                'options'       => sali_post_name(),
            ),

            array(
                'mode' => 'section_end',
            ),
            array(
                'mode'    => 'section_start',
                'id'      => 'sec_meta_query',
                'label'   => __( 'Display Options', 'paper-elements' ),
            ),           
            array(
                'type'    => Controls_Manager::CHOOSE,
                'id'      => 'post_title_tag',
                'label'   => esc_html__( 'Title HTML Tag', 'paper-elements' ),
                'options' => array(
                    'h1'  => [
                        'title' => esc_html__( 'H1', 'paper-elements' ),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2'  => [
                        'title' => esc_html__( 'H2', 'paper-elements' ),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3'  => [
                        'title' => esc_html__( 'H3', 'paper-elements' ),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4'  => [
                        'title' => esc_html__( 'H4', 'paper-elements' ),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5'  => [
                        'title' => esc_html__( 'H5', 'paper-elements' ),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6'  => [
                        'title' => esc_html__( 'H6', 'paper-elements' ),
                        'icon' => 'eicon-editor-h6'
                    ]
                  
                ),
                'default' => 'h3',
                'label_block' => true,
                'toggle' => false,
            ),

            array(
                'type'    => Controls_Manager::NUMBER,
                'id'      => 'post_title_length',
                'label'   => __( 'Post Title Length', 'paper-elements' ),
                'default' => '10',
            ),
             array( 
                    'mode'      => 'group',
                    'type'      => Group_Control_Typography::get_type(),
                    'name'      => 'post_title_typography',                
                    'label'     => esc_html__( 'Typography', 'paper-elements' ),
                    'selector'  => '{{WRAPPER}} .page-title',
                ),
            array(              
                'id'    => 'hr-post-modern-slider-1',
                'type'  => Controls_Manager::DIVIDER,               
                'style' => 'thick',
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'post_date',
                'label'       => __( 'Display Post Date', 'paper-elements' ),
                'label_on'    => __( 'Show', 'paper-elements' ),
                'label_off'   => __( 'Hide', 'paper-elements' ),
                'default'     => 'no',
            ), 
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'post_author',
                'label'       => __( 'Display Author Name', 'paper-elements' ),
                'label_on'    => __( 'Show', 'paper-elements' ),
                'label_off'   => __( 'Hide', 'paper-elements' ),
                'default'     => 'yes',
            ),  
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'post_shares',
                'label'       => __( 'Display post shares', 'paper-elements' ),
                'label_on'    => __( 'Show', 'paper-elements' ),
                'label_off'   => __( 'Hide', 'paper-elements' ),
                'default'     => 'yes',
                'return_value' => 'yes',
            ),  
            array(
                'mode' => 'section_end',
            ),
            
        );
        return $fields;

    }

  protected function _register_controls() {
    $fields = $this->sali_fields();
    foreach ( $fields as $field ) {
      if ( isset( $field['mode'] ) && $field['mode'] == 'section_start' ) {
        $id = $field['id'];
        unset( $field['id'] );
        unset( $field['mode'] );
        $this->start_controls_section( $id, $field );
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'section_end' ) {
        $this->end_controls_section();
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'group' ) {
        $type = $field['type'];
        unset( $field['mode'] );
        unset( $field['type'] );
        $this->add_group_control( $type, $field );
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'responsive' ) {
        $id = $field['id'];
        unset( $field['id'] );
        unset( $field['mode'] );
        $this->add_responsive_control( $id, $field );
      }
      else {
        $id = $field['id'];
        unset( $field['id'] );
        $this->add_control( $id, $field );
      }
    }
  }

private function sali_scripts(){
    wp_enqueue_style( 'slick' );
     
    wp_enqueue_script( 'slick' );
}

protected function render() {
        $settings = $this->get_settings();  
        $this->sali_scripts();

        if ( $settings['style'] == 'style2' ) {
        $template = 'post-modern-slider-2';
        } else {            
        $template = 'post-modern-slider-1';
        }

        return Sali_Elements_Helper::sali_element_template( $template, $settings );
    }
}

