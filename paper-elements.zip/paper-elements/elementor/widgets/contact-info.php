<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class Contact_Info extends Widget_Base {
    public $sali_name;
    public $sali_base;
    public $sali_category;
    public $sali_icon;
    public $sali_translate;
    public function __construct( $settings = [], $args = null ) {
        $this->sali_category = SALI_ELEMENTS_PRFX . '-widgets'; // Category /@dev
        $this->sali_icon     = 'eicon-info-circle-o';
        $this->sali_name = esc_html__( 'Paper Contact Info', 'paper-elements' );

        $this->sali_base = 'paper-contact-info';

        parent::__construct( $settings, $args );
    }
    public function get_name() {
        return $this->sali_base;
    }
    public function get_title() {
        return $this->sali_name;
    }
    public function get_icon() {
        return $this->sali_icon;
    }
    public function get_categories() {
        return array( $this->sali_category );
    }

    public function sali_fields(){

        $fields = array(
            array(
                'mode'    => 'section_start',
                'id'      => 'sec_general',
                'label'   => esc_html__( 'General', 'paper-elements' ),
            ),

            array(
                'id' => 'contact_info_note',
                'label' => esc_html__( 'Edit/Remove Content ? Go To Theme Options - Generel - Contact and Socials', 'paper-elements' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ),
            array(
                'mode'      => 'group',
                'type'      => Group_Control_Background::get_type(),
                'types'     => array(
                    'classic',
                    'gradient'
                ),
                'name'      => 'contact_info_box_background',
                'label'     => esc_html__( 'Background Color', 'paper-elements' ),
                'selector'  => '{{WRAPPER}} .sali-contact-info-inner',
            ),
            array(
                'name'      => 'contact_info_box_padding',
                'id'        => 'contact_info_box_padding',
                'type'      => Controls_Manager::DIMENSIONS,
                'label'     => esc_html__( 'Padding', 'paper-elements' ),
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .sali-contact-info-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ),

            array(
                'mode' => 'section_end',
            ),
        );
        return $fields;
    }



    protected function _register_controls() {
        $fields = $this->sali_fields();
        foreach ( $fields as $field ) {
            if ( isset( $field['mode'] ) && $field['mode'] == 'section_start' ) {
                $id = $field['id'];
                unset( $field['id'] );
                unset( $field['mode'] );
                $this->start_controls_section( $id, $field );
            }
            elseif ( isset( $field['mode'] ) && $field['mode'] == 'section_end' ) {
                $this->end_controls_section();
            }
            elseif ( isset( $field['mode'] ) && $field['mode'] == 'group' ) {
                $type = $field['type'];
                unset( $field['mode'] );
                unset( $field['type'] );
                $this->add_group_control( $type, $field );
            }
            elseif ( isset( $field['mode'] ) && $field['mode'] == 'responsive' ) {
                $id = $field['id'];
                unset( $field['id'] );
                unset( $field['mode'] );
                $this->add_responsive_control( $id, $field );
            }
            else {
                $id = $field['id'];
                unset( $field['id'] );
                $this->add_control( $id, $field );
            }
        }
    }

    protected function render() {
        $settings = $this->get_settings();
        $template   = 'contact-info-1';
        return Sali_Elements_Helper::sali_element_template( $template, $settings );
    }
}
