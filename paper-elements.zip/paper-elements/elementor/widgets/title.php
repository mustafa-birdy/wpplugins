<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class Title extends Widget_Base {  
    public $sali_name;
    public $sali_base;
    public $sali_category;
    public $sali_icon;
    public $sali_translate;
    public function __construct( $settings = [], $args = null ) {
        $this->sali_category = SALI_ELEMENTS_PRFX . '-widgets'; // Category /@dev
        $this->sali_icon     = 'eicon-post-title';
        $this->sali_name = esc_html__( 'Paper Section Title', 'paper-elements' );

        $this->sali_base = 'salinews-title';

        parent::__construct( $settings, $args );
    }
    public function get_name() {
        return $this->sali_base;
    }
    public function get_title() {
        return $this->sali_name;
    }
    public function get_icon() {
        return $this->sali_icon;
    }
    public function get_categories() {
        return array( $this->sali_category );
    }

    public function sali_fields(){
        
           $fields = array(
            array(
                'mode'    => 'section_start',
                'id'      => 'sec_general',
                'label'   => esc_html__( 'General', 'paper-elements' ),
            ),
            
             array(
                'type'    => Controls_Manager::CHOOSE,
                'id'      => 'sec_title_tag',
                'label'   => esc_html__( 'Title HTML Tag', 'paper-elements' ),
                'options' => array(
                    'h1'  => [
                        'title' => esc_html__( 'H1', 'paper-elements' ),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2'  => [
                        'title' => esc_html__( 'H2', 'paper-elements' ),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3'  => [
                        'title' => esc_html__( 'H3', 'paper-elements' ),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4'  => [
                        'title' => esc_html__( 'H4', 'paper-elements' ),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5'  => [
                        'title' => esc_html__( 'H5', 'paper-elements' ),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6'  => [
                        'title' => esc_html__( 'H6', 'paper-elements' ),
                        'icon' => 'eicon-editor-h6'
                    ],
                    'div'  => [
                        'title' => esc_html__( 'div', 'paper-elements' ),
                        'icon' => 'eicon-font'
                    ]
                ),
                'default' => 'h2',
                'toggle' => false,

            ),  
            array(
                'type'    => Controls_Manager::TEXTAREA,
                'id'      => 'title',
                'label'   => __( 'Title', 'paper-elements' ),
                'default' => 'ALL RECENT NEWS',
                
            ),
            array(
                'type'    => Controls_Manager::COLOR,
                'id'      => 'title_color',
                'label'   => __( 'Title Color', 'paper-elements' ),
                'default' => '#000000',
                'selectors' => array(
                    '{{WRAPPER}} .sali-title' => 'color: {{VALUE}}',
                ),
                
            ),
            array( 
                'mode'      => 'group',
                'type'      => Group_Control_Typography::get_type(),
                'name'      => 'title_font_size',                
                'label'     => esc_html__( 'Icon Typography', 'paper-elements' ),
                'selector'  => '{{WRAPPER}} .sali-title',
            ),

            array(
                'type'              => Controls_Manager::SLIDER,
                'mode'              => 'responsive',
                'id'            => 'bottom_title_spacing',
                'label'         => __( 'Bottom Spacing', 'paper-elements' ),                
                'size_units' => array( 'px' ),              
                'default' => array(
                'unit' => 'px',
                'size' => 20,
                ),
                    'selectors' => array(
                        '{{WRAPPER}} .section-title' => 'margin-bottom: {{SIZE}}{{UNIT}}  !important;',                        
                    )
                ),

            array(
                'label'         => esc_html__( 'Title Button', 'paper-elements' ),
                'type'          => Controls_Manager::SWITCHER,
                'id'            => 'has_title_button',
                'label_on'      => esc_html__( 'Show', 'paper-elements' ),
                'label_off'     => esc_html__( 'Hide', 'paper-elements' ),
                'return_value'  => 'yes',
                'default'       => 'yes',    
                                        
            ),      

             // Link Start
                array(
                    'id'        => 'sali_post_grid_link_text',
                    'label'     => esc_html__( 'Button Text', 'paper-elements' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => 'ALL RECENT NEWS',
                    'title'     => esc_html__( 'Enter button text', 'paper-elements' ),
                    'condition' => array( 'has_title_button' => array( 'yes' ) ) ,
                    
                ),
                array(
                    'id'        => 'sali_post_grid_link_type',
                    'label'     => esc_html__( 'Button Link Type', 'paper-elements' ),
                    'type'      => Controls_Manager::SELECT,
                    
                    'options' => array(
                        '1' => esc_html__( 'Custom Link', 'paper-elements' ),
                        '2' => esc_html__( 'Internal Page', 'paper-elements' ),
                       
                    ),
                    'default'   => '1',    
                     'condition' => array( 'has_title_button' => array( 'yes' ) ) ,                
                ),

                array(
                    'type'    => Controls_Manager::URL,
                    'id'      => 'sali_post_grid_custom_link',
                    'label'   => __( 'Button URL', 'paper-elements' ),
                    'placeholder' => 'https://your-link.com',
                   'condition' => array( 
                            'sali_post_grid_link_type' => array( '1' ),
                            'has_title_button' => array( 'yes' ),
                           
                         ),
                ),                
                array(
                    'id'            => 'sali_post_grid_page_link',
                    'label'         => esc_html__( 'Select Button Page', 'paper-elements' ),
                    'type'          => Controls_Manager::SELECT2,                    
                    'options'       => sali_get_all_pages(),                   
                       'condition' => array( 
                            'sali_post_grid_link_type' => array( '2' ),
                            'has_title_button' => array( 'yes' ),
                            
                         ),
                ),
            array(
                'mode' => 'section_end',
            ),
        );
        return $fields;
    }


  
  protected function _register_controls() {
    $fields = $this->sali_fields();
    foreach ( $fields as $field ) {
      if ( isset( $field['mode'] ) && $field['mode'] == 'section_start' ) {
        $id = $field['id'];
        unset( $field['id'] );
        unset( $field['mode'] );
        $this->start_controls_section( $id, $field );
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'section_end' ) {
        $this->end_controls_section();
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'group' ) {
        $type = $field['type'];
        unset( $field['mode'] );
        unset( $field['type'] );
        $this->add_group_control( $type, $field );
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'responsive' ) {
        $id = $field['id'];
        unset( $field['id'] );
        unset( $field['mode'] );
        $this->add_responsive_control( $id, $field );
      }
      else {
        $id = $field['id'];
        unset( $field['id'] );
        $this->add_control( $id, $field );
      }
    }
  }

    protected function render() {
        $settings = $this->get_settings();        
        $template   = 'title-1';
        return Sali_Elements_Helper::sali_element_template( $template, $settings );
    }
}
