<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class sali_post_category_list extends Widget_Base {
    public $sali_name;
    public $sali_base;
    public $sali_category;
    public $sali_icon;
    public $sali_translate;
    public function __construct( $settings = [], $args = null ) {
        $this->sali_category = SALI_ELEMENTS_PRFX . '-widgets'; // Category /@dev
        $this->sali_icon     = 'eicon-form-vertical';
        $this->sali_name = esc_html__( 'Paper Category list', 'paper-elements' );
        $this->sali_base = 'salinews-post-category-list';
        $this->sali_translate = array(
            'cols'  => array(
                '1' =>esc_html__( '1 Col', 'paper-elements' ),
                '2'  =>esc_html__( '2 Col', 'paper-elements' ),
                '3'  =>esc_html__( '3 Col', 'paper-elements' ),
                '4'  =>esc_html__( '4 Col', 'paper-elements' ),
                '5'  =>esc_html__( '5 Col', 'paper-elements' ),
                '6'  =>esc_html__( '6 Col', 'paper-elements' ),
            ),
        );
        parent::__construct( $settings, $args );
    }
    public function get_name() {
        return $this->sali_base;
    }
    public function get_title() {
        return $this->sali_name;
    }
    public function get_icon() {
        return $this->sali_icon;
    }
    public function get_categories() {
        return array( $this->sali_category );
    }
    public function sali_fields(){    
        $categories = get_categories();
        foreach ( $categories as $category ) {
            $category_dropdown[$category->slug] = $category->name;
        }        

       
         $fields = array(       

            array(
                'mode'    => 'section_start',
                'id'      => 'sec_layout',
                'label'   => esc_html__( 'General option', 'paper-elements' ),
            ),        
    
              array(
                'type'    => Controls_Manager::SELECT2,
                'id'    => 'category_lists',
                'label'   => __( 'Categories', 'salinews-elements' ),
                'options' => $category_dropdown,
                'multiple'=> true,
                'default' => '1',
            ),
        
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'style',
                'label'   => esc_html__( 'List Type', 'paper-elements' ),
                'options' => array(
                    'style1' => esc_html__( 'Grid', 'paper-elements' ),
                    'style2' => esc_html__( 'Carousel' , 'paper-elements' ),                  
                ),
                'default' => 'style1',
            ),
           
             array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'show_count',
                'label'       => esc_html__( 'Show count ', 'paper-elements' ),
                'label_on'    => esc_html__( 'Show', 'paper-elements' ),
                'label_off'   => esc_html__( 'Hide', 'paper-elements' ),
                'default'     => 'no',
            ),             
          array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'hide_empty_category',
                'label'       => esc_html__( 'Hide empty category ', 'paper-elements' ),
                'label_on'    => esc_html__( 'Show', 'paper-elements' ),
                'label_off'   => esc_html__( 'Hide', 'paper-elements' ),
                'default'     => 'no',
            ),             
       
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'orderby',
                'label'   => esc_html__( 'Post Ordering', 'paper-elements' ),
                'options' => array(
                    'id'        =>  esc_html__( 'ID', 'paper-elements' ),
                    'Count'     =>  esc_html__( 'Count', 'paper-elements'),
                    'Name'      =>  esc_html__( 'Name', 'paper-elements' ),
                    'Slug'      =>  esc_html__( 'Slug', 'paper-elements' ), 
                ),
                'default' => 'Name',
            ),              
            array(
                    'type'    => Controls_Manager::SELECT2,
                    'id'      => 'Order',
                    'label'   => esc_html__( 'Ordering', 'paper-elements' ),
                    'options' => array(
                        'ASC'        =>  esc_html__( 'ASC', 'paper-elements' ),
                        'DESC'     =>  esc_html__( 'DESC', 'paper-elements'),
                        
                    ),
                    'default' => 'ASC ',
                ),              
            array(
                'mode' => 'section_end',
            ),
            array(
                'mode'        => 'section_start',
                'id'          => 'sec_slider',
                'label'       => esc_html__( 'Slider Options', 'paper-elements' ),
                'condition'   => array( 'style' => array( 'style2' ) ),
            ),          
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'slider_nav',
                'label'       => esc_html__( 'Navigation Arrow', 'paper-elements' ),
                'label_on'    => esc_html__( 'On', 'paper-elements' ),
                'label_off'   => esc_html__( 'Off', 'paper-elements' ),
                'default'     => 'yes',
                'description' => esc_html__( 'Enable or disable navigation arrow. Default: On', 'paper-elements' ),
            ),           
           
            array(
                'mode' => 'section_end',
            ),  

                              
        );
        return $fields;

    }

  protected function _register_controls() {
    $fields = $this->sali_fields();
    foreach ( $fields as $field ) {
      if ( isset( $field['mode'] ) && $field['mode'] == 'section_start' ) {
        $id = $field['id'];
        unset( $field['id'] );
        unset( $field['mode'] );
        $this->start_controls_section( $id, $field );
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'section_end' ) {
        $this->end_controls_section();
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'group' ) {
        $type = $field['type'];
        unset( $field['mode'] );
        unset( $field['type'] );
        $this->add_group_control( $type, $field );
      }
      elseif ( isset( $field['mode'] ) && $field['mode'] == 'responsive' ) {
        $id = $field['id'];
        unset( $field['id'] );
        unset( $field['mode'] );
        $this->add_responsive_control( $id, $field );
      }
      else {
        $id = $field['id'];
        unset( $field['id'] );
        $this->add_control( $id, $field );
      }
    }
  }
    private function sali_owl_scripts(){
        wp_enqueue_style(  'owl-carousel' );
        wp_enqueue_style(  'owl-theme-default' );
        wp_enqueue_script( 'owl-carousel' ); 
    } 
    private function sali_counterup_scripts(){    
        wp_enqueue_script( 'counterup' );
        wp_enqueue_script( 'waypoints' );
        
    }

protected function render() {
        $settings = $this->get_settings();  
            if ($settings['style'] == 'style2') {
                $this->sali_owl_scripts();
                $this->sali_counterup_scripts();

                  $carousel_data = array( 
                    'nav'                => $settings['slider_nav'] == 'yes' ? true : false,
                    'dots'               => false,
                    'navText'            => array( "<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>" ),
                    'autoplay'           =>  false,                 
                    'loop'               => false,
                    'margin'             => 0,
                    'responsive'         => array(
                        '768'  => array( 'items' => '2' ),
                        '992'  => array( 'items' => '4' ),
                        '1200' => array( 'items' => '5'),
                )
            );
            $settings['carousel_data'] = json_encode( $carousel_data );
            $template = 'post-category-list-2';
        } else {            
              $this->sali_counterup_scripts();
            $template = 'post-category-list-1';
        }        
        return Sali_Elements_Helper::sali_element_template( $template, $settings);
    }
}
