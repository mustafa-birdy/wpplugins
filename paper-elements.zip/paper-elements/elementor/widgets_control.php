<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */

    if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

    class Sali_Widgets_Control{
        public function __construct(){
            $this->sali_widgets_control();                  
            
        }

  // Controll Widgets
    public function sali_widgets_control(){
        $sectiontitle = 'on';
        $widgets_manager = \Elementor\Plugin::instance()->widgets_manager; 

        // Section Title
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/title.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/title.php';
            $widgets_manager->register_widget_type( new Title() );
        }   
        // Post single
         if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-single.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-single.php';
            $widgets_manager->register_widget_type( new saliNews_post_single() );
        }     
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-single-banner.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-single-banner.php';
            $widgets_manager->register_widget_type( new saliNews_post_single_banner() );
        }    
        //single video post
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-single-video.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-single-video.php';
            $widgets_manager->register_widget_type( new sali_post_single_video() );
        } 
        // Post grid
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-grid.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-grid.php';
            $widgets_manager->register_widget_type( new sali_post_grid() );
        } 
       // Post list  
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-list.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-list.php';
            $widgets_manager->register_widget_type( new sali_post_list() );
        }       
       
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-carousel-single-column.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-carousel-single-column.php';
            $widgets_manager->register_widget_type( new sali_post_carousel_single_column() );
        }  
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-multi-video.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-multi-video.php';
            $widgets_manager->register_widget_type( new sali_post_multi_video() );
        }       
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-minimal.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-minimal.php';
            $widgets_manager->register_widget_type( new sali_post_minimal() );
        } 
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-masonry.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-masonry.php';
            $widgets_manager->register_widget_type( new sali_post_masonry() );
        }     
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-category-list.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/post-category-list.php';
            $widgets_manager->register_widget_type( new sali_post_category_list() );
        }  
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/post-modern-slider.php' ) && $sectiontitle === 'on' ) {
            require_once SALI_PL_PATH.'elementor/widgets/post-modern-slider.php';
            $widgets_manager->register_widget_type( new sali_post_modern_slider() );
        } 
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/team.php' ) && $sectiontitle === 'on' ) {                
            require_once SALI_PL_PATH.'elementor/widgets/team.php';
            $widgets_manager->register_widget_type( new Team_Grid() );
        }
        if ( file_exists( SALI_PL_PATH .'elementor/widgets/contact-info.php' ) && $sectiontitle === 'on' ) {
            require_once SALI_PL_PATH.'elementor/widgets/contact-info.php';
            $widgets_manager->register_widget_type( new Contact_Info() );
        }

              
    }
}    
new Sali_Widgets_Control();