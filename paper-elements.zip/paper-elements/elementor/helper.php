<?php

/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package paper-elements
 */
class Sali_Elements_Helper
{
    public static function sali_element_template($template, $settings)
    {
        $template_name = "/elementor-custom/templates/{$template}.php";
        if (file_exists(STYLESHEETPATH . $template_name)) {
            $file = STYLESHEETPATH . $template_name;
        } elseif (file_exists(TEMPLATEPATH . $template_name)) {
            $file = TEMPLATEPATH . $template_name;
        } else {
            $file = __DIR__ . "/widgets/templates/{$template}.php";
        }

        ob_start();
        include $file;
        echo ob_get_clean();
    }

}


/*
 * All Post Name
 * return array
 */
function sali_post_name($post_type = 'post')
{
    $options = array();
    $options = ['0' => esc_html__('None', 'paper-elements')];
    $sali_post = array('posts_per_page' => -1, 'post_type' => $post_type);
    $sali_post_terms = get_posts($sali_post);
    if (!empty($sali_post_terms) && !is_wp_error($sali_post_terms)) {
        foreach ($sali_post_terms as $term) {
            $options[$term->ID] = $term->post_title;
        }
        return $options;
    }
}

/**
 * Get all Pages
 */
if (!function_exists('sali_get_all_pages')) {
    function sali_get_all_pages()
    {

        $page_list = get_posts(array(
            'post_type' => 'page',
            'orderby' => 'date',
            'order' => 'DESC',
            'posts_per_page' => -1,
        ));

        $pages = array();

        if (!empty($page_list) && !is_wp_error($page_list)) {
            foreach ($page_list as $page) {
                $pages[$page->post_name] = $page->post_title;
            }
        }

        return $pages;
    }
}


/**
 * Get Post Thumbnail Size
 */



if (!function_exists('paper_get_thumbnail_sizes')) {
    function paper_get_thumbnail_sizes()
    {
//        $sizes = get_intermediate_image_sizes();
//        foreach ($sizes as $s) {
//            $value[$s] = $s;
//        }
//
//        return $value;


        global $_wp_additional_image_sizes;
        $default_image_sizes = [ 'thumbnail', 'medium', 'medium_large', 'large' ];
        $image_sizes = [];
        foreach ( $default_image_sizes as $size ) {
            $image_sizes[ $size ] = [
                'width' => (int) get_option( $size . '_size_w' ),
                'height' => (int) get_option( $size . '_size_h' ),
                'crop' => (bool) get_option( $size . '_crop' ),
            ];
        }
        if ( $_wp_additional_image_sizes ) {
            $image_sizes = array_merge( $image_sizes, $_wp_additional_image_sizes );
        }
        $wp_image_sizes = apply_filters( 'image_size_names_choose', $image_sizes );
        $image_sizes = [];
        foreach ( $wp_image_sizes as $size_key => $size_attributes ) {
            $control_title = ucwords( str_replace( '_', ' ', $size_key ) );
            if ( is_array( $size_attributes ) ) {
                $control_title .= sprintf( ' - %d x %d', $size_attributes['width'], $size_attributes['height'] );
            }
            $image_sizes[ $size_key ] = $control_title;
        }
        $image_sizes['full'] = _x( 'Full', 'Image Size Control', 'elementor' );
        return $image_sizes;
    }
}

