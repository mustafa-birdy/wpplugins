<?php

namespace Elementor;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

trait NwccGlobalFunctions
{
    protected function get_post_category($taxonomy = "category")
    {
        $category_array = array();
        $args = array(
            'taxonomy' => $taxonomy,
        );

        $categories_list = get_categories($args);


        if ($categories_list) {
            foreach ($categories_list as $categories) {
                $category_array[$categories->slug] = $categories->name;
            }
        }

        return $category_array;
    }

    protected function get_posts_by_post_type($postType = "post")
    {
        $postsarr = array();
        $posts = get_posts(array('posts_per_page' => -1, 'post_type' => $postType));
        if ($posts && !is_wp_error($posts)) {
            foreach ($posts as $post) {
                $postsarr[$post->post_name] = $post->post_title;
            }
        }
        return $postsarr;
    }

    protected function nwcc_get_posts()
    {
        global $wpdb;
        $acfPosts = array();
        $posts = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_status = 'publish' AND post_type='acf-field-group' AND post_excerpt='testimonial-settings'");
        if (isset($posts[0]->ID) && !empty($posts[0]->ID)) {
            $fields = acf_get_fields_by_id($posts[0]->ID);
            if (isset($fields[0]['choices']) && !empty($fields[0]['choices'])) {
                $acfPosts = $fields[0]['choices'];
            }
        }
        return $acfPosts;
    }
}
