<?php

$select_image_size = $settings['image_size'];
if (isset($select_image_size) && !empty($select_image_size)){
    $sali_image_size = $select_image_size;
}else{
    $sali_image_size  = "sali-size-md";
}

if ( $query->have_posts() ) { 
    $title_limit = $settings['post_title_length'];
    while ( $query->have_posts() ) {
    $query->the_post(); 
        $post_id = get_the_ID();
        $excerpt = wp_trim_words(get_the_excerpt(), $content_limit, '');
        $ptitle = wp_trim_words(get_the_title($post_id), $title_limit, '');               
        $author = $query->post_author;

        ?>                
        <div class="sali-item animated fadeInUp <?php echo esc_attr( $col_class );?>">
            <div class="sali-img-container m-b-xs-30 ">
            <?php Helper::get_generate_thumbnail_image($post_id, $class = "img-fluid m-r-xs-30", $settings, $sali_image_size); ?>           
                <div class="media post-block grad-overlay position-absolute">
                    <div class="media-body justify-content-end">
                        <?php if ( $settings['cat_display'] ) { ?>              
                            <div class="sali-img-cat post-cat-group m-b-xs-10">
                                <?php echo sali_get_the_category($post_id); ?>
                            </div>
                        <?php
                        } 
                        ?>
                        <div class="sali-media-bottom">
                            <<?php echo esc_html( $settings['post_title_tag'] );?> class="sali-post-title m-b-xs-0">
                                    <a href="<?php the_permalink(); ?>"><?php echo esc_html( $ptitle ); ?></a>
                                </<?php echo esc_html( $settings['post_title_tag'] );?>>
                            
                            <?php if ( $settings['content_display'] == 'yes'){ ?>
                                <P class="big"><?php echo wp_kses_post( $excerpt ); ?></p>
                            <?php } ?>

                            <?php echo Helper::SaliPostMetas( $settings, $post_id); ?>
                        </div>
                    </div>
                </div>
            <!-- End of .post-block -->
            </div>
            <!-- End of .sali-img-container -->
        </div>
<?php }
}
?>