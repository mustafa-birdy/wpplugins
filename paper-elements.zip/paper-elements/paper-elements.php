<?php
/*
Plugin Name: Paper Elements
Description: Essential Element for Paper Theme
Version: 3

*/

if (!defined('ABSPATH')) exit;
if (!defined('SALI_ELEMENTS')) {
    define('SALI_ELEMENTS', (WP_DEBUG) ? time() : '1.0');
    define('SALI_ELEMENTS_PRFX', 'paper-elements');
    define('SALI_ELEMENTS_THEME_PRFX', 'paper');
    define('SALI_FIX_PRFX', 'sali');

    define('SALI_ELEMENTS_VERSION', (WP_DEBUG) ? time() : '1.14');
    define('SALI_PL_PATH', plugin_dir_path(__FILE__));
    define('SALI_PL_URL', plugins_url('/', __FILE__));
}

class Sali_Elements
{
    public $plugin = 'paper-elements';
    public $action = 'paper_theme_init';

    public function __construct()
    {
        add_action('plugins_loaded', array($this, 'sali_elementor_textdomain'), 16);
        add_action('after_setup_theme', array($this, 'elementor_widgets'));
        add_action('elementor/elements/categories_registered', array($this, 'widget_categoty'));
        add_action('elementor/widgets/widgets_registered', array($this, 'elementor_widgets_control'));
        /*ajax actions*/
        add_action('wp_ajax_sali_loadmore_news', array($this, 'sali_loadmore_news'));
        add_action('wp_ajax_nopriv_sali_loadmore_news', array($this, 'sali_loadmore_news'));
        add_filter('elementor/widgets/wordpress/widget_args', array($this, 'sali_elementor_widget_args'));

    }

    public function sali_elementor_textdomain()
    {
        load_plugin_textdomain($this->plugin, false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function widget_categoty($class)
    {
        $id = SALI_ELEMENTS_PRFX . '-widgets';
        $properties = array(
            'title' => esc_html__('Paper Elements', 'paper-elements'),
        );

        \Elementor\Plugin::$instance->elements_manager->add_category($id, $properties);
    }

    public function elementor_widgets_control()
    {
        if (did_action('elementor/loaded')) {
            require_once 'elementor/widgets_control.php';
        }
    }

    public function elementor_widgets()
    {
        require_once 'elementor/helper.php';
    }


    function sali_elementor_widget_args($args)
    {
        $args['before_widget'] = '<div class="widget paper-elementor-sidebar">';
        $args['after_widget'] = '</div>';
        $args['before_title'] = '<h3>';
        $args['after_title'] = '</h3>';
        return $args;
    }

    public function sali_loadmore_news()
    {
        $html = null;
        $remaining = true;
        $settings = $_POST['data'];
        $page = absint($_POST['page']) + 1;
        $number_of_post = $settings['number_of_post'];
        $post_sorting = $settings['post_sorting'];
        $post_ordering = $settings['post_ordering'];
        $catID = $_POST['catID'];
        $html = $cat_link = null;
        $cat_link = get_category_link($catID);

        $args = array(
            'cat' => $catID,
            'post_status' => 'publish',
            'orderby' => $post_sorting,
            'order' => $post_ordering,
            'posts_per_page' => $number_of_post,
            'paged' => $page
        );

        switch ($settings['orderby']) {
            case 'title':
            case 'menu_order':
                $args['order'] = 'ASC';
                break;
        }

        $query = new WP_Query($args);
        $query = new WP_Query($args);
        $col_class = "col-lg-{$settings['col_lg']} col-md-{$settings['col_md']} col-sm-{$settings['col_sm']} col-xs-{$settings['col_xs']}";
        $temp = Helper::wp_set_temp_query($query);
        if ($query->have_posts()) :
            if ($query->max_num_pages == $page) {
                $remaining = false;
            }
            ob_start();

            include('elementor/template/post-grid-3.php');

        else:
            $remaining = false;
        endif;
        $html = ob_get_clean();
        $var = $_POST;
        wp_send_json(compact('html', 'page', 'remaining', 'query'));
    }

}

new Sali_Elements;