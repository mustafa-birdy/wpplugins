<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package sali-panels
 */


class sali_Posts_Widget extends WP_Widget {
		public function __construct() {
			$id = 'sali-panels_posts';
			parent::__construct(
	        $id, // Base ID
	        esc_html__( 'paper: Recent Posts', 'sali-panels' ), // Name
	        array( 'description' => esc_html__( 'Paper: Recent Posts Widget', 'sali-panels' ) 
	        	) );
		}
		public function widget($args, $instance) {
			if (!isset($args['widget_id'])) {
				$args['widget_id'] = $this->id;
			}
			
			$title                = (!empty($instance['title'])) ? $instance['title'] : esc_html__('Recent Posts', 'sali-panels');
			$title                = apply_filters('widget_title', $title, $instance, $this->id_base);
			$number               = (!empty($instance['number'])) ? absint($instance['number']) : 5;
			$content_limit        = (!empty($instance['content_limit'])) ? absint($instance['content_limit']) : 10;
			if (!$number) {
				$number = 3;
			}

			$title_limit          = (!empty($instance['title_limit'])) ? absint($instance['title_limit']) : 10;
			$show_img     = isset($instance['show_img']) ? $instance['show_img'] : false;
			$show_date    = isset($instance['show_date']) ? $instance['show_date'] : false;
			$show_content = isset($instance['show_content']) ? $instance['show_content'] : false;
			$show_cat = isset($instance['show_cat']) ? $instance['show_cat'] : false;
			$thumb_size = 'thumbnail';

			$result_query = new WP_Query(apply_filters('widget_posts_args', array(
				'posts_per_page'      => $number,
				'no_found_rows'       => true,
				'post_status'         => 'publish',
				'ignore_sticky_posts' => true,
			)));
			if ($result_query->have_posts()):
			?>
				<?php echo wp_kses_post($args['before_widget']); ?>
				<?php if ($title) {
						echo wp_kses_post($args['before_title']) . $title . wp_kses_post($args['after_title']);
					}?>
				<?php while ($result_query->have_posts()): $result_query->the_post();

					$post_id = get_the_ID();

					$content = Helper::get_current_post_content();
					$content = "<p>$content</p>";
					$content = wp_trim_words( $content, $content_limit );

					$title = get_the_title();
					$title = wp_trim_words( $title, $title_limit );
				?>

				<div class="media post-block post-block__small">
						<?php if (has_post_thumbnail()) {?>
		            	<?php if ($show_img): ?> 							
							<a href="<?php the_permalink();?>" class="align-self-center m-r-xs-30" title="<?php the_title_attribute();?>">
									<?php the_post_thumbnail($thumb_size);?>							
							</a>								
	                 <?php endif;?>
	                 <?php } ?>
					<div class="media-body">
						<?php if ($show_date):  ?>
							<div class="post-cat-group">
								<?php echo sali_get_the_category_color($post_id); ?>
							</div>
						<?php  endif; ?>
						<h3 class="sali-post-title"><a href="<?php the_permalink();?>"> <?php echo wp_kses_post( $title );?></a></h3>
						<?php if ($show_content): ?>
							<div class="p-content"><?php echo wp_kses_post( $content );?></div>
						<?php endif;?> 
						<?php if ($show_date): ?>
						<div class="post-metas">
							<ul class="list-inline">
								<li> <?php esc_html_e( 'By ' , 'sali-panels'); ?>  &nbsp; <?php the_author_posts_link();?></li>
								<li><i class="dot">.</i><?php echo get_the_time( get_option( 'date_format' ) ); ?></li>
							</ul>
						</div>
						<?php endif;?>	
					</div>
				</div>				         
			<?php endwhile;?>
		<?php echo wp_kses_post($args['after_widget']); ?>
		<?php
        wp_reset_postdata();
			endif;
		}
		public function update($new_instance, $old_instance) {
			$instance                  = $old_instance;
			$instance['title']         = sanitize_text_field($new_instance['title']);
			$instance['number']        = (int) $new_instance['number'];
			$instance['title_limit'] = (int) $new_instance['title_limit'];
			$instance['content_limit'] = (int) $new_instance['content_limit'];
			$instance['title_limit'] = (int) $new_instance['title_limit'];
			$instance['show_img']      = isset($new_instance['show_img']) ? (bool) $new_instance['show_img'] : false;
			$instance['show_date']     = isset($new_instance['show_date']) ? (bool) $new_instance['show_date'] : false;
			$instance['show_content']  = isset($new_instance['show_content']) ? (bool) $new_instance['show_content'] : false;
			$instance['show_cat']  = isset($new_instance['show_cat']) ? (bool) $new_instance['show_cat'] : false;
			return $instance;
		}
		public function form($instance) {
			$defaults = array(
				'title'         => esc_html__('Latest Post', 'sali-panels'),
				'number'        => '3',
				'show_img'     	=> true,
				'show_date'     => true,
				'show_content'  => false,
				'show_cat'  	=> true,
				'title_limit' 	=> '6',
				'content_limit' => '6',
			);
			$instance = wp_parse_args((array) $instance, $defaults);

			$fields = array(
				'title'         => array(
					'label' => esc_html__('Title', 'sali-panels'),
					'type'  => 'text',
				),
				'number'        => array(
					'label' => esc_html__('Number of posts to show', 'sali-panels'),
					'type'  => 'number',				

				),
				'content_limit' => array(
					'label' => esc_html__('Content limit of posts to show', 'sali-panels'),
					'type'  => 'number',					
				),	
				'title_limit' => array(
					'label' => esc_html__('Title limit of posts to show', 'sali-panels'),
					'type'  => 'number',					
				),
				'show_img'  => array(
					'label' =>esc_html__('Display post Image ?', 'sali-panels'),
					'type'  => 'checkbox',
				),
				'show_content'  => array(
					'label' => esc_html__('Display post Content ?', 'sali-panels'),
					'type'  => 'checkbox',
				),
				'show_date'     => array(
					'label' => esc_html__('Display post meta ?', 'sali-panels'),
					'type'  => 'checkbox',
				),
				'show_cat'     => array(
					'label' => esc_html__('Display category ?', 'sali-panels'),
					'type'  => 'checkbox',
				),
			);

			AP_Widget_Fields::display($fields, $instance, $this);
		}
	}
