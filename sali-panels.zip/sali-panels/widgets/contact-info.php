<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package sali-panels
 */



class Contact_info_Widget extends WP_Widget {
	public function __construct() {
		$id = 'sali-panels_contact_info';
		parent::__construct(
            $id, // Base ID
            esc_html__( 'paper: Contact Info', 'sali-panels' ), // Name
            array( 'description' => esc_html__( 'Sali News: Contact Info', 'sali-panels' )
            	) );
	}

	public function widget( $args, $instance ){
		echo wp_kses_post( $args['before_widget'] );

		if ( !empty( $instance['logo'] ) ) {

			$html = '<div class="footer-logo"><a class="footer-widget-logo" href="'. esc_url( home_url( '/' ) ) . '">'. wp_get_attachment_image( $instance['logo'], 'full' ) .'</a></div>';
		}
		elseif ( !empty( $instance['title'] ) ) {
			$html = apply_filters( 'widget_title', $instance['title'] );
			$html = $args['before_title'] . $html .$args['after_title'];
		}
		else {
			$html = '';
		}

		echo wp_kses_post( $html );
		?>
		<p><?php if( !empty( $instance['description'] ) ) echo wp_kses_post( $instance['description'] ); ?></p>

		<?php if( !empty( $instance['description'] ) ) { ?>
			<p>
		<?php echo wp_kses_post( $instance['description']); ?> 
			</p>
		<?php } ?>


		<div class="footer-box">	
			<ul class="corporate-address">
					<?php 
					if( !empty( $instance['phone1'] ) ){
						?><li> 
							<i class="fa fa-phone" aria-hidden="true"></i> 
							<p><a href="tel:<?php echo esc_attr( $instance['phone1'] ); ?>"><?php echo esc_html( $instance['phone1'] ); ?></a></p>
							<p><a href="tel:<?php echo esc_attr( $instance['phone2'] ); ?>"><?php echo esc_html( $instance['phone2'] ); ?></a></p>
						</li><?php
					}

					if( !empty( $instance['email1'] ) ){
						?><li><i class="fa fa-envelope-o" aria-hidden="true"></i> 
							<p><a href="mailto:<?php echo esc_attr( $instance['email1'] ); ?>"><?php echo esc_html( $instance['email1'] ); ?></a></p>
							<p><a href="mailto:<?php echo esc_attr( $instance['email2'] ); ?>"><?php echo esc_html( $instance['email2'] ); ?></a></p>
							</li><?php
					}
					
					if( !empty( $instance['address'] ) ){
						?><li> <i class="fa fa-map-marker" aria-hidden="true"></i><p><?php echo wp_kses_post( $instance['address'] ); ?></p></li><?php
					}	
					?>
				</ul>
		</div>
		
		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	public function update( $new_instance, $old_instance ){
		$instance                  = array();
		$instance['title']         = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['logo']          = ( ! empty( $new_instance['logo'] ) ) ? sanitize_text_field( $new_instance['logo'] ) : '';
		$instance['description']   = ( ! empty( $new_instance['description'] ) ) ? wp_kses_post( $new_instance['description'] ) : '';
		$instance['address']   = ( ! empty( $new_instance['address'] ) ) ? wp_kses_post( $new_instance['address'] ) : '';
		$instance['phone1']     = ( ! empty( $new_instance['phone1'] ) ) ? sanitize_text_field( $new_instance['phone1'] ) : '';		
		$instance['phone2']     = ( ! empty( $new_instance['phone2'] ) ) ? sanitize_text_field( $new_instance['phone2'] ) : '';		
		$instance['email1']     = ( ! empty( $new_instance['email1'] ) ) ? sanitize_email( $new_instance['email1'] ) : '';
		$instance['email2']     = ( ! empty( $new_instance['email2'] ) ) ? sanitize_email( $new_instance['email2'] ) : '';
		
		return $instance;
	}

	public function form( $instance ){
		$defaults = array(
			'title'         => '',
			'logo'          => '',
			'description'   => '',
			'address' 		=> '',
			'phone1'   		=> '',			
			'phone2'   		=> '',			
			'email1'   		=> '',
			'email2'   		=> '',
		);
		$instance = wp_parse_args( (array) $instance, $defaults );

		$fields = array(
			'title'       => array(
				'label'   => esc_html__( 'Title', 'sali-panels' ),
				'type'    => 'text',
			),
			'logo'        => array(
				'label'   => esc_html__( 'Logo', 'sali-panels' ),
				'type'    => 'image',
			),
			'description' => array(
				'label'   => esc_html__( 'Description', 'sali-panels' ),
				'type'    => 'textarea',
			),
			'address'   => array(
				'label' => esc_html__( 'Address', 'sali-panels' ),
				'type'  => 'textarea',
			),
			'phone1'     => array(
				'label' => esc_html__( 'Phone 1', 'sali-panels' ),
				'type'  => 'text',
			),	
			'phone2'     => array(
				'label' => esc_html__( 'Phone2', 'sali-panels' ),
				'type'  => 'text',
			),					
			'email1'     => array(
				'label' => esc_html__( 'Email1', 'sali-panels' ),
				'type'  => 'text',
			),
			'email2'     => array(
				'label' => esc_html__( 'Email2', 'sali-panels' ),
				'type'  => 'text',
			),
			
		);

		AP_Widget_Fields::display( $fields, $instance, $this );
	}
}