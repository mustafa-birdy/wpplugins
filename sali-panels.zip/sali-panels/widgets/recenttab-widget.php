<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package sali-panels
 */


class RecentTab_Widget extends WP_Widget
{
    public function __construct()
    {
        parent::__construct(
            'sali-tabbed-recent-widget',
            'Paper - Recent Tabs',
            array('description' => esc_html__('Tabs: Recent, Popular, Category, Tags etc', 'sali-panels'), 'classname' => 'tabbed')
        );

        add_action('save_post', array($this, 'flush_widget_cache'));
        add_action('edit_post', array($this, 'flush_widget_cache')); // comments covered
        add_action('deleted_post', array($this, 'flush_widget_cache'));
        add_action('switch_theme', array($this, 'flush_widget_cache'));
        add_action('sali_widget_flush_cache', array($this, 'flush_widget_cache'));

        // enqueue
        add_action('admin_enqueue_scripts', array($this, 'add_assets'));

    }

    public function add_assets($hook)
    {
        wp_enqueue_script('widget-tabs', plugins_url('/sali-panels/assets/js/widget-tabs.js'));
    }

    public function widget($args, $instance)
    {
        global $post;

        $thumb_size = 'thumbnail';

        // set defaults
        $titles = $cats = $tax_tags = array();

        extract($args);
        extract($instance);

        if (!count($titles) OR !count($cats)) {
            _e('Recent tabs widget still need to be configured! Add tabs, add a title, and select type for each tab in widgets area.', 'sali-panels');
            return;
        }

        $tabs = array();
        foreach ($titles as $key => $title) {
            if (empty($tax_tags[$key])) {
                $tax_tags[$key] = '';
            }

            if (empty($cats[$key])) {
                $cats[$key] = '';
            }

            if (empty($posts[$key])) {
                $posts[$key] = (!empty($number) ? $number : 4);
            }

            $tabs[$title] = array('cat_type' => $cats[$key], 'tag' => $tax_tags[$key], 'posts' => $posts[$key]);

        }

        // latest posts
        $posts = $this->get_posts($tabs);

        // do custom loop if available
        if (has_action('sali_widget_tabbed_recent_loop')):

            $args['tabs'] = $tabs;
            do_action('sali_widget_tabbed_recent_loop', $args, $posts);

        else:

            ?>

            <?php echo wp_kses_post($before_widget); ?>
            <div class="post-widget sidebar-post-widget m-b-xs-30">
                <ul class="nav nav-pills row no-gutters">

                    <?php
                    $count = 0;
                    foreach ($posts as $key => $val): $count++;
                        $active = ($count == 1 ? 'active' : '');
                        ?>
                        <li class="nav-item col">
                            <a class="nav-link <?php echo esc_attr($active); ?>"
                               href="#recent-post-<?php echo esc_attr($count); ?>"
                               data-toggle="pill"
                            ><?php echo esc_html($key); ?></a>
                        </li>
                    <?php endforeach; ?>

                </ul>

                <div class="tab-content">
                    <?php
                    $i = 0;
                    foreach ($posts as $tab => $tab_posts): $i++;
                        $active = ($i == 1 ? 'active show' : ''); ?>
                        <div class="tab-pane fade <?php echo esc_attr($active); ?>" id="recent-post-<?php echo esc_attr($i); ?>">
                            <div class="content">

                                <?php while ($tab_posts->have_posts()): $tab_posts->the_post(); ?>
                                    <div class="media post-block post-block__small">
                                        <?php if (has_post_thumbnail()) { ?>
                                            <a href="<?php the_permalink() ?>" class="align-self-center">
                                                <?php the_post_thumbnail($thumb_size, array('class' => 'm-r-xs-30')); ?>
                                            </a>
                                        <?php } ?>
                                        <div class="media-body">
                                            <div class="post-cat-group">
                                                <?php
                                                $categories = get_the_category();
                                                $separator = ' ';
                                                $output = '';
                                                if (!empty($categories)) {
                                                    foreach ($categories as $category) {
                                                        $get_color = get_term_meta($category->term_id, 'sali_category_color', true);

                                                        if ($get_color) { ?>
                                                            <a style="color:<?php echo esc_attr($get_color); ?>"
                                                               class="post-cat"
                                                               href="<?php echo get_category_link($category->term_id); ?>"><?php echo esc_html($category->name); ?></a>
                                                        <?php } else { ?>
                                                            <a class="post-cat"
                                                               href="<?php echo get_category_link($category->term_id); ?>"><span
                                                                        class="el-rt-cat style_2"><?php echo esc_html($category->name); ?><span
                                                                            class="titleinner"></span></span></a>
                                                        <?php }
                                                    }
                                                } ?>
                                            </div>

                                            <h4 class="sali-post-title hover-line hover-line"><a
                                                        href="<?php the_permalink() ?>"><?php the_title(); ?></a></h4>
                                            <div class="post-metas">
                                                <ul class="list-inline">
                                                    <li><?php esc_html_e('By &nbsp;', 'sali-panels'); ?><?php the_author_posts_link(); ?></li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End of .post-block -->
                                <?php endwhile; ?>
                                <!-- End of .post-block -->
                            </div>
                            <!-- End of .content -->
                        </div>
                    <?php endforeach; ?>
                    <!-- End of .tab-pane -->

                </div>
            </div>

            <?php echo wp_kses_post($after_widget); ?>

        <?php

        endif; // end custom loop

        wp_reset_postdata();
        wp_reset_query();

    }

    public function get_posts($tabs)
    {
        // posts available in cache? - use instance id to suffix
        $cache = get_transient('sali_tabbed_recent_posts');

        if (!defined('ICL_LANGUAGE_CODE') && is_array($cache) && isset($cache[$this->number])) {
            return $cache[$this->number];
        }

        // get posts
        $args = array('ignore_sticky_posts' => 1);
        foreach ($tabs as $key => $val) {

            $opts = array();
            $opts['posts_per_page'] = $val['posts'];

            switch ($val['cat_type']) {
                case 'popular':
                    $opts['orderby'] = 'comment_count';
                    break;

                case 'recent':
                    break;

                case 'view':
                    
                    $opts['orderby']  = 'meta_value_num';
                    $opts['meta_key'] = 'sali_views';
                    break;

                case 'tag':
                    $opts['tag'] = $val['tag'];
                    break;

                default:
                    $opts['cat'] = intval($val['cat_type']);
                    break;
            }

            // setup the query
            $posts[$key] = new WP_Query(apply_filters('sali_widget_tabbed_recent_query_args', array_merge($args, $opts)));
        }

        if (!is_array($cache)) {
            $cache = array();
        }

        $cache[$this->number] = $posts;

        set_transient('sali_tabbed_recent_posts', $cache, 60 * 60 * 24 * 30); // 30 days transient cache

        return $posts;
    }

    public function flush_widget_cache()
    {
        delete_transient('sali_tabbed_recent_posts');
    }

    public function update($new, $old)
    {
        // fix categories
        foreach (array('cats', 'titles', 'tax_tags', 'posts') as $var) {

            foreach ($new[$var] as $key => $val) {
                $new[$var][$key] = trim(strip_tags($val));
            }

        }

        $new['number'] = intval($new['number']);

        // delete cache
        $this->flush_widget_cache();

        return $new;
    }

    public function form($instance)
    {
        $instance = array_merge(array('titles' => array(), 'cats' => array(0), 'number' => 4, 'cat' => 0, 'tax_tags' => array()), $instance);

        extract($instance);

        ?>

        <style>
            .widget-content p.separator {
                padding-top: 10px;
                border-top: 1px solid #d8d8d8;
            }

            .widget-content .tax_tag {
                display: none;
            }
        </style>


        <div id="tab-options">


            <script type="text/html" class="template-tab-options">
                <p class="title separator">
                    <label><?php printf(__('Tab #%s Title:', 'sali-panels'), '<span>%n%</span>'); ?></label>
                    <input class="widefat" name="<?php
                    echo esc_attr($this->get_field_name('titles')); ?>[%n%]" type="text" value="%title%"/>
                </p>


                <div class="cat">
                    <label><?php printf(__('Tab #%s Category:', 'sali-panels'), '<span>%n%</span>'); ?></label>
                    <?php

                    $r = array('orderby' => 'name', 'hierarchical' => 1, 'selected' => $cat, 'show_count' => 0);

                    // categories list
                    $cats_list = walk_category_dropdown_tree(get_terms('category', $r), 0, $r);

                    // custom options
                    $options = apply_filters('sali_widget_tabbed_recent_options', array(
                        'recent' => esc_html__('Recent Posts', 'sali-panels'),
                        'popular' => esc_html__('Popular Posts', 'sali-panels'),
                        'view' => esc_html__('View', 'sali-panels'),
                        'tag' => esc_html__('Use a Tag', 'sali-panels'),
                    ));

                    ?>

                    <select name="<?php echo $this->get_field_name('cats') . '[%n%]'; ?>">

                        <?php foreach ($options as $key => $val): ?>

                            <option value="<?php echo esc_attr($key); ?>"<?php echo($cat == $key ? ' selected' : ''); ?>><?php echo esc_html($val); ?></option>

                        <?php endforeach; ?>

                        <optgroup label="<?php _e('Category', 'sali-panels'); ?>">
                            <?php echo $cats_list; ?>
                        </optgroup>

                    </select>

                    <div class="tax_tag">
                        <p><label><?php printf(__('Tab #%s Tag:', 'sali-panels'), '<span>%n%</span>'); ?></label> <input
                                    type="text" name="<?php
                            echo esc_attr($this->get_field_name('tax_tags')); ?>[%n%]" value="%tax_tag%"/></p>
                    </div>

                    <p><?php _e('Posts:', 'sali'); ?> <input name="<?php echo $this->get_field_name('posts'); ?>[%n%]"
                                                             type="text" value="%posts%" size="3"/></p>

                    <p><a href="#" class="remove-recent-tab">[x] <?php _e('remove', 'sali-panels'); ?></a></p>
                </div>
            </script>


            <p class="separator"><a href="#" id="add-more-tabs"><?php _e('Add More Tabs', 'sali-panels'); ?></a></p>

            <?php

            if (is_integer($this->number)): // create for valid instances only

                foreach ($cats as $n => $cat):

                    if (!isset($tax_tags[$n])) {
                        $tax_tags[$n] = '';
                    }

                    // set posts to default number
                    if (!isset($posts[$n])) {
                        $posts[$n] = $number;
                    }
                    ?>

                    <script>
                        jQuery(function ($) {

                            $('.widget-liquid-right [id$="sali-tabbed-recent-widget-' + <?php echo $this->number; ?> +'"] #add-more-tabs').trigger(
                                'click',
                                [{
                                    'n': <?php echo($n + 1); ?>,
                                    'title': '<?php echo esc_attr($titles[$n]); ?>',
                                    'selected': '<?php echo esc_attr($cat); ?>',
                                    'tax_tag': '<?php echo esc_attr($tax_tags[$n]); ?>',
                                    'posts': '<?php echo esc_attr($posts[$n]); ?>',
                                }]);
                        });
                    </script>

                <?php
                endforeach;
            endif;
            ?>

        </div>

        <?php
    }

}