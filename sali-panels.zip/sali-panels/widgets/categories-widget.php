<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package sali-panels
 */


class Categories_Widget extends WP_Widget {
	public function __construct() {
		$id = 'sali-panels_categories';
		parent::__construct(
            $id, // Widget Base ID
            esc_html__( 'paper: Categories', 'sali-panels' ), // Widget Name
            array( 'description' => esc_html__( 'paper: Categories Widget', 'sali-panels' )
            	) );
	}
	public function widget( $args, $instance ){	
			echo wp_kses_post( $args['before_widget'] );

			if (!isset($args['widget_id'])) {
				$args['widget_id'] = $this->id;
			}
				$title                	= (!empty($instance['title'])) ? $instance['title'] : esc_html__('Categories', 'sali-panels');
				$title                	= apply_filters('widget_title', $title, $instance, $this->id_base);			
				$show_count 		  	= isset($instance['show_count']) ? $instance['show_count'] : false;
				$hide_empty_category  	= isset($instance['hide_empty_category']) ? $instance['hide_empty_category'] : false;				
				$orderby  				= isset($instance['orderby']) ? $instance['orderby'] : 'name';
				$order  				= isset($instance['order']) ? $instance['order'] : 'ASC';
				$categories 			= get_terms( 'category', array(
				    'hide_empty' 		=> $hide_empty_category,
				    'orderby'           => $orderby,
				    'order'             => $order, 
				) );
				$categories_number_of_total = count($categories);
				$html = apply_filters( 'widget_title', $title );
				$html = $args['before_title'] . $html . $args['after_title'];
			
			echo wp_kses_post( $html );
			$responsive = array(
					'0'    => array( 'items' => 1),
					'480'  => array( 'items' => 1),
					'768'  => array( 'items' => 1),
					'992'  => array( 'items' => 1),
					'1200' => array( 'items' => 1),
			);	
			$owl_data = array( 
				'navText'            => array( "<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>" ),
				'nav'                => true,
				'dots'               => false,
				'autoplay'           => false,
				'autoplayTimeout'    => '5000',
				'autoplaySpeed'      => '200',
				'autoplayHoverPause' => true,
				'loop'               => 1,
				'margin'             => 30,
				'responsive'         => $responsive
			);
			$owl_data = json_encode( $owl_data );
        wp_enqueue_style( 'owl-theme-default' );
        wp_enqueue_style( 'owl-carousel' );
				wp_enqueue_script( 'owl-carousel' );
			?>
			<div class="category-carousel">		
				<div class="owl-wrap sali-nav-top">				
						<div class="owl-theme owl-carousel sali-paper-carousel" data-carousel-options="<?php echo esc_attr( $owl_data );?>">
						<?php 
						$count = 1;
						$i = 0;
						foreach( $categories as $category ):						
						$category_background_image 							= get_term_meta( $category->term_id, 'sali_category_image', true );
						$i++;
						$category_background_color 			= get_term_meta( $category->term_id, 'sali_category_color', true );
						
						if ($category_background_image) {
							$bg = 'style="background-image: url('.$category_background_image.')"';
							$has_overlay = 'overlay';
						} elseif($category_background_color) {
							$bg = 'style="background-color: '.$category_background_color.'"';
							$has_overlay = '';
						} else {
							$bg = "";
							$has_overlay = '';
						}
						echo ($count == 1 ) ? '<div class="cat-carousel-inner"><ul class="category-list-wrapper">' : ''; ?>								
						<li class="category-list perfect-square">
							<a href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>" class="list-inner" <?php echo saliescap($bg); ?>
								>
								<div class="post-info-wrapper <?php echo saliescap($has_overlay); ?>"> 
									<?php if ( $show_count ): ?>
										<div class="counter-inner"><span class="counter"><?php echo wp_kses_post($category->count); ?></span>
										</div>
									<?php endif ?>
									<?php if ( !empty($category->name) ): ?>
										<h4 class="cat-title"><?php echo esc_html($category->name); ?></h4>
									<?php endif ?>
								</div>
								<!-- End of .counter-wrapper -->
							</a>
						</li>
						<?php  if( $count == 4 || $i == $categories_number_of_total){
						echo "</ul></div>";
							$count = 1;
						}else{
							$count++;
						}
						endforeach; ?>					
					<!-- End of .category-list-wrapper -->
				</div>
				<!-- End of .cat-carousel-inner -->
			</div>
			<!-- End of  .owl-carousel -->
		</div>		
		<?php
		echo wp_kses_post( $args['after_widget'] );
	}
	public function update( $new_instance, $old_instance ){
		$instance                  = array();
		$instance['title']         = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['show_count']    		= isset($new_instance['show_count']) ? (bool) $new_instance['show_count'] : false;
		$instance['hide_empty_category']    = isset($new_instance['hide_empty_category']) ? (bool) $new_instance['hide_empty_category'] : false;
		$instance['orderby']    	= isset($new_instance['orderby']) ? $new_instance['orderby'] : 'name';
		$instance['order']    		= isset($new_instance['order']) ? $new_instance['order'] : 'ASC';		
		return $instance;
	}
	public function form( $instance ){
		$defaults = array(
			'title'         => '',
			'show_count'    => true,
			'hide_empty_category' => false,
			'orderby' 			  => 'name',
			'order' 			  => 'ASC',
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		$fields = array(
			'title'       => array(
				'label'   => esc_html__( 'Title', 'sali-panels' ),
				'type'    => 'text',
			),
			'show_count'  => array(
				'label'   => esc_html__( 'Display post Content ?', 'sali-panels' ),
				'type'    => 'checkbox',
			),
			'hide_empty_category'  => array(
				'label'   => esc_html__( 'Hide Empty Category!', 'sali-panels' ),
				'type'    => 'checkbox',
			),
			'orderby'  => array(
				'label'   => esc_html__( 'Orderby', 'sali-panels' ),
				'type'    => 'select',
				'options' => array(
					'id' 		=> 'ID',
					'count' 	=> 'Count',
					'name' 		=> 'Name',
					'slug' 		=> 'Slug',
				)
			),
			'order'  => array(
				'label'   => esc_html__( 'Order', 'sali-panels' ),
				'type'    => 'select',
				'options' => array(
					'ASC' 		=> 'ASC',
					'DESC' 		=> 'DESC',
				),
			),
			
		);

		AP_Widget_Fields::display( $fields, $instance, $this );
	}
}