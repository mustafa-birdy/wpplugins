jQuery(document).ready(function($){
	'use strict';


	// Image upload field
	$("body").on('click', '.ap_upload_image', function(event) {
		var btnClicked = $(this);
		var custom_uploader = wp.media({
			multiple: false
		}).on("select", function () {
			var attachment = custom_uploader.state().get("selection").first().toJSON();
			btnClicked.closest(".ap_metabox_image").find(".custom_upload_image").val(attachment.id);
			btnClicked.closest(".ap_metabox_image").find(".custom_preview_image").attr("src", attachment.url).show();
			btnClicked.closest(".ap_metabox_image").find(".ap_remove_image_wrap").show();

		}).open();
	});

	$("body").on('click', '.ap_remove_image', function(event) {
		event.preventDefault();
		$(this).closest(".ap_metabox_image").find(".custom_upload_image").val("");
		$(this).closest(".ap_metabox_image").find(".custom_preview_image").attr("src", "").hide();
		$(this).closest(".ap_metabox_image").find(".ap_remove_image_wrap").hide();
		return false;
	});

});

