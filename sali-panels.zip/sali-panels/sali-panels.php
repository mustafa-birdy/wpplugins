<?php
/*
Plugin Name: Sali Panels
Description: Extended Paper Themes Feature
Version: 3
Author: kissygirl
*/
if (!defined('ABSPATH')) {
    exit;
}
if (!defined('SALI_PANELS')) {
    define('SALI_PANELS_VERSION', (WP_DEBUG) ? time() : '1.0');
    define('SALI_PANELS_THEME', 'paper');
    define('SALI_PANELS_FIX', 'sali');
    define('SALI_PANELS_URL', plugins_url('/', __FILE__));
    define('SALI_PANELS_DIR', dirname(__FILE__));
}

include_once(SALI_PANELS_DIR . '/includes/paper-after-activation.php');
register_activation_hook(__FILE__, 'paper_activate_core');

class sali_panels
{
    protected static $instance = null;
    public $plugin = 'sali-panels';
    public $action = 'sali_theme_init';
    public $panels = 'sali_panels_init';
    public $version = SALI_PANELS_VERSION;
    public $base_url = null;

    public function __construct()
    {
        $this->base_url = $this->get_base_url() . '/sali-panels/';
        add_action('plugins_loaded', array($this, 'sali_load_textdomain'), 16);
        add_action('after_setup_theme', array($this, 'sali_post_types'), 15);
        add_action('widgets_init', array($this, 'custom_widgets'));
        add_action('init', array($this, 'initialize'), 12);

        add_action("redux/options/paper/saved", array($this, 'sali_flush_redux_saved'), 10, 2);
        add_action("redux/options/paper/section/reset", array($this, 'sali_flush_redux_reset'));
        add_action("redux/options/paper/reset", array($this, 'sali_flush_redux_reset'));
        add_action('init', array($this, 'sali_rewrite_flush_check'));

    }


    public function sali_load_textdomain()
    {
        load_plugin_textdomain($this->plugin, false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function sali_post_types()
    {
        if (!did_action($this->action)) {
            return;
        }
        require_once 'includes/redux-panels.php';
        require_once 'includes/sali-posts.php';
        require_once 'includes/cmb2/cmb2-taxonomy/taxonomy-meta.php';
        require_once 'includes/post-types.php';
        require_once 'includes/cmb2/cmb2-radio-image.php';
        require_once 'includes/cmb2/post-meta.php';
        require_once 'includes/cmb2/user-meta.php';
        require_once 'includes/ap-widget-fields.php';
        require_once 'includes/sidebar-generator.php';

        // widgets
        require_once 'widgets/post-widget.php';
        require_once 'widgets/info-widget.php';
        require_once 'widgets/about-widget.php';
        require_once 'widgets/contact-info.php';
        require_once 'widgets/categories-widget.php';
        require_once 'widgets/recenttab-widget.php';


    }

    // widgets register
    public function custom_widgets()
    {
        if (!class_exists('AP_Widget_Fields')) return;
        register_widget('Contact_info_Widget');
        register_widget('sali_Posts_Widget');
        register_widget('Information_Widget');
        register_widget('About_Widget');
        register_widget('Categories_Widget');
        register_widget('RecentTab_Widget');
    }

    private function get_base_url()
    {
        $file = dirname(dirname(__FILE__));
        // Get correct URL and path to wp-content
        $content_url = untrailingslashit(dirname(dirname(get_stylesheet_directory_uri())));
        $content_dir = untrailingslashit(WP_CONTENT_DIR);
        // Fix path on Windows
        $file = wp_normalize_path($file);
        $content_dir = wp_normalize_path($content_dir);
        $url = str_replace($content_dir, $content_url, $file);
        return $url;
    }

    public function initialize()
    {
        add_action('admin_enqueue_scripts', array($this, 'load_styles_and_scripts'));
    }

    public function load_styles_and_scripts()
    {
        wp_enqueue_media();
        wp_enqueue_script('ap-posts-script', $this->base_url . 'assets/js/script.js', array('jquery', 'jquery-ui-core', 'wp-color-picker', 'jquery-ui-datepicker'), $this->version);
        wp_enqueue_style('ap-posts-style', $this->base_url . 'assets/css/style.css', array(), $this->version);
    }


// Flush rewrites
    public function sali_flush_redux_saved($saved_options, $changed_options)
    {
        if (empty($changed_options)) {
            return;
        }
        $panelspfix = SALI_PANELS_THEME;
        $flush = false;
        $slugs = array('team_slug', 'team_cat_slug');
        foreach ($slugs as $slug) {
            if (array_key_exists($slug, $changed_options)) {
                $flush = true;
            }
        }

        if ($flush) {
            update_option("{$panelspfix}_rewrite_flash", true);
        }
    }

    public function sali_flush_redux_reset()
    {
        $panelspfix = SALI_PANELS_THEME;
        update_option("{$panelspfix}_rewrite_flash", true);
    }

    public function sali_rewrite_flush_check()
    {
        $panelspfix = SALI_PANELS_THEME;
        if (get_option("{$panelspfix}_rewrite_flash") == true) {
            flush_rewrite_rules();
            update_option("{$panelspfix}_rewrite_flash", false);
        }
    }
    
}

new sali_panels;