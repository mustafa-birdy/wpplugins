<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package sali-panels
 */

	class SALI_Posttype {		
		protected static $instance = null;
		private $post_types = array();
		private $taxonomies = array();

		private function __construct() {
			add_action( 'init', array( $this, 'initialize' ) );
		}

		public static function getInstance() {
			if ( null == self::$instance ) {
				self::$instance = new self;
			}
			return self::$instance;
		}

		public function initialize() {
			$this->register_custom_post_types();
			$this->register_taxonomies();
		}

		public function SALI_post_types_add( $post_types ) {

			foreach ( $post_types as $post_type => $args ) {

				$title = $args['title'];
				$plural_title = empty( $args['plural_title'] ) ? $title . 's' : $args['plural_title'];
				
				if ( ! empty( $args['rewrite'] ) ) {
					$args['rewrite'] = array( 'slug' => $args['rewrite'] );
				}

				$labels      = array(
					'name'               => $plural_title,
					'singular_name'      => $title,
					'add_new'            => esc_html__( 'Add New', 'sali-panels' ),
					'add_new_item'       => esc_html__( 'Add New', 'sali-panels' ) .' '. $title,
					'edit_item'          => esc_html__( 'Edit', 'sali-panels' ) .' '. $title,
					'new_item'           => esc_html__( 'New', 'sali-panels' ) .' '. $title,
					'all_items'          => esc_html__( 'All', 'sali-panels' ) .' '. $plural_title,
					'view_item'          => esc_html__( 'View', 'sali-panels' ) .' '. $title,
					'search_items'       => esc_html__( 'Search', 'sali-panels' ) .' '. $plural_title,
					'not_found'          => $plural_title . esc_html__( ' not found', 'sali-panels' ),
					'not_found_in_trash' => $plural_title . esc_html__( ' not found in Trash', 'sali-panels' ),
					'parent_item_colon'  => '',
					'menu_name'          => $plural_title
					);

				if ( !empty( $args['labels_override'] ) ) {
					$labels = wp_parse_args( $args['labels_override'], $labels );
				}

				$defaults = array(
					'labels'             => $labels,
					'public'             => true,
					'publicly_queryable' => true,
					'show_ui'            => true,
					'show_in_menu'       => true,
					'show_in_nav_menus'  => true,
					'query_var'          => true,
					'has_archive'        => true,
					'hierarchical'       => false,
					'menu_position'      => null,
					'menu_icon'          => null,
					'supports'           => array( 'title', 'thumbnail', 'editor' )
					);

				$args = wp_parse_args( $args, $defaults );
				$this->post_types[ $post_type ] = $args;
			}
		}

		public function SALI_taxonomies_add( $taxonomies ) {

			foreach ($taxonomies as $taxonomy => $args ) {

				$title = $args['title'];
				$plural_title = empty( $args['plural_title'] ) ? $title . 's' : $args['plural_title'];

				$labels     = array(
					'name'              => $title,
					'singular_name'     => $title,
					'search_items'      => esc_html__( 'Search', 'sali-panels' ) .' '. $plural_title,
					'all_items'         => esc_html__( 'All', 'sali-panels' ) .' '. $plural_title,
					'parent_item'       => esc_html__( 'Parent', 'sali-panels' ) .' '. $title,
					'parent_item_colon' => esc_html__( 'Parent', 'sali-panels' ) .' '. $title.':',
					'edit_item'         => esc_html__( 'Edit', 'sali-panels' ) .' '. $title,
					'update_item'       => esc_html__( 'Update', 'sali-panels' ) .' '. $title,
					'add_new_item'      => esc_html__( 'Add New', 'sali-panels' ) .' '. $title,
					'new_item_name'     => esc_html__( 'New name of', 'sali-panels' ) .' '. $title,
					'menu_name'         => $plural_title,
					);

				if ( !empty( $args['labels_override'] ) ) {
					$labels = wp_parse_args( $args['labels_override'], $labels );
				}

				$defaults = array(
					'hierarchical'      => true,
					'labels'            => $labels,
					'show_in_nav_menus' => true,
					'show_ui'           => null,
					'show_admin_column' => true,
					'query_var'         => true,
					'rewrite'           => array( 'slug' => $taxonomy )
					);

				$args = wp_parse_args( $args, $defaults );
				$this->taxonomies[ $taxonomy ] = $args;
			}
		}

		private function register_custom_post_types() {
			foreach ( $this->post_types as $post_type => $args ) {
				register_post_type( $post_type, $args );
			}
		}

		private function register_taxonomies() {
			foreach ( $this->taxonomies as $taxonomy => $args ) {				
				register_taxonomy( $taxonomy, $args['post_types'], $args );
			}
		}
	}


SALI_Posttype::getInstance();