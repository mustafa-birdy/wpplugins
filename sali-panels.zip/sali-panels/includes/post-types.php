<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package sali-panels
 */

$prefix = SALI_PANELS_FIX;
$paper_options 	= Helper::sali_get_options();
$sali_post_types = array(
	"team"     		=> array(
		'title'        			=> esc_html__('Team', 'sali-panels' ),
		'plural_title' 			=> esc_html__('Team', 'sali-panels' ),
		'menu_icon'    			=> 'dashicons-businessman',
		'rewrite'      			=> $paper_options['team_slug'],
		'supports'     			=> array( 'title', 'thumbnail', 'editor', 'excerpt', 'page-attributes' )
	),	
);

$sali_taxonomies = array(
	"team_category"        	=> array(
		'title'        				 	=> esc_html__( 'Category', 'xmet-panels' ),
		'plural_title' 				 	=> esc_html__( 'Categories', 'xmet-panels' ),
		'post_types'   				 	=> "team",		
		'rewrite' 	   				 	=> array('slug' => $paper_options['team_cat_slug']),
	),
	
);
$sali_Posts = SALI_Posttype::getInstance();
$sali_Posts->SALI_post_types_add( $sali_post_types );
$sali_Posts->SALI_taxonomies_add( $sali_taxonomies );
