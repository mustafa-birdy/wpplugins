<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package sali-panels
 */


class sali_metabox {
	public function __construct() {
		// Register widget areas.
		add_action( 'cmb2_admin_init', array(
			$this,
			'sali_metabox',
		) );
	}

	public function sali_metabox() {
		$nav_menus = wp_get_nav_menus( array( 'fields' => 'id=>name' ) );
		$nav_menus = array( 'default' => esc_html__( 'Default', 'sali-panels' ) ) + $nav_menus;
		$sidebars  = array( 'default' => esc_html__( 'Default', 'sali-panels' ) ) + Helper::get_custom_sidebar_fields();
		$prefix = SALI_PANELS_FIX;
		// metabox for page Mata Layout

		$cmb2_Page_MataLayout = new_cmb2_box( array(
			'id'           => $prefix . '_page_settings',
			'title'        => esc_html__( 'Layout Settings', 'sali-panels' ),
			'object_types' => array('page','post','team'), // Post type
			'context'      => 'normal',
			'priority'     => 'high',
			'show_names'   => true, // Show field names on the left
		) );
		$cmb2_Page_MataLayout->add_field( array(
		    'name'             => esc_html__( 'Layout', 'sali-panels' ),
		    'id'               => $prefix.'_layout',
		    'type'             => 'select',
		    'default'          => 'default',
		    'options'          => array(
		        'default'          => esc_html__( 'Default', 'sali-panels' ),
		        'full-width'       => esc_html__( 'Full Width', 'sali-panels' ),
	            'left-sidebar'     => esc_html__( 'Left Sidebar', 'sali-panels' ),
		        'right-sidebar'    => esc_html__( 'Right Sidebar', 'sali-panels' )
		    ),
		) );


		$cmb2_Page_MataLayout->add_field( array(
		    'name'             =>  esc_html__( 'Custom Sidebar', 'sali-panels' ),
		    'id'               => $prefix.'_sidebar',
		    'type'             => 'select',
		    'default'          => 'default',
		    'options'          => $sidebars,
		) );

		// header & footer
		$cmb2_Page_header_footer_MataLayout = new_cmb2_box( array(
			'id'           => $prefix . '_page_header_footer_settings',
			'title'        => esc_html__( 'Header / Footer Settings', 'sali-panels' ),
			'object_types' => array('page','post', 'team'), // Post type
			'context'      => 'normal',
			'priority'     => 'high',
			'show_names'   => true, // Show field names on the left
		) );


		$cmb2_Page_header_footer_MataLayout->add_field( array(
		    'name'             =>  esc_html__( 'Main Menu', 'sali-panels' ),
		    'id'               => $prefix.'_page_menu',
		    'type'             => 'select',
		    'default'          => 'default',
		    'options'          => $nav_menus,
		) );

		$cmb2_Page_header_footer_MataLayout->add_field( array(
		    'name'              =>  esc_html__( 'Display Header Top', 'sali-panels' ),
		    'id'                => $prefix.'_top_bar',
		    'type'              => 'select',
		    'default'           => 'default',
		    'options'           => array(
		        'default'   => esc_html__( 'Default', 'sali-panels' ),
				'on'        => esc_html__( 'Enable', 'sali-panels' ),
				'off'       => esc_html__( 'Disable', 'sali-panels' ),
		    ),
		) );
        $cmb2_Page_header_footer_MataLayout->add_field( array(
            'name'              =>  esc_html__( 'Display Header', 'sali-panels' ),
            'id'                => $prefix.'_header_area',
            'type'              => 'select',
            'default'           => 'default',
            'options'           => array(
                'default'   => esc_html__( 'Default', 'sali-panels' ),
                'on'        => esc_html__( 'Enable', 'sali-panels' ),
                'off'       => esc_html__( 'Disable', 'sali-panels' ),
            ),
        ) );
		$cmb2_Page_header_footer_MataLayout->add_field( array(
			 'name'             =>  esc_html__( 'Header Layout', 'sali-panels' ),
		    'id'               => $prefix.'_header',
			'type'             => 'radio_image',
		    'default'          => 'default',
			'options'          => array(
				'default' => esc_html__( 'Default', 'sali-panels' ),
				'1'       => esc_html__( 'Layout 1', 'sali-panels' ),
				'2'       => esc_html__( 'Layout 2', 'sali-panels' ),
				'3'       => esc_html__( 'Layout 3', 'sali-panels' ),
				'4'       => esc_html__( 'Layout 4', 'sali-panels' ),
				'5'       => esc_html__( 'Layout 5', 'sali-panels' ),
				// '6'       => esc_html__( 'Layout 6', 'sali-panels' ),

			),
			'images_path'      => get_template_directory_uri(),
			'images'           => array(
				'default' => 'assets/img/header-footer-layout/header-default.jpg',
				'1'       => 'assets/img/header-footer-layout/header-01.jpg',
				'2'       => 'assets/img/header-footer-layout/header-02.jpg',
				'3'       => 'assets/img/header-footer-layout/header-03.jpg',
				'4'       => 'assets/img/header-footer-layout/header-04.jpg',
				'5'       => 'assets/img/header-footer-layout/header-05.jpg',
				'6'       => 'assets/img/header-footer-layout/header-06.jpg',

			)
		) );
		$cmb2_Page_header_footer_MataLayout->add_field( array(
		    'name'              =>  esc_html__( 'Display Footer Top', 'sali-panels' ),
		    'id'                => $prefix.'_footer_top',
		    'type'              => 'select',
		    'default'           => 'default',
		    'options'           => array(
                'default'   => esc_html__( 'Default', 'sali-panels' ),
				'on'        => esc_html__( 'Enable', 'sali-panels' ),
				'off'       => esc_html__( 'Disable', 'sali-panels' ),
		    ),
		) );
        $cmb2_Page_header_footer_MataLayout->add_field( array(
            'name'              =>  esc_html__( 'Display Footer', 'sali-panels' ),
            'id'                => $prefix.'_footer_area',
            'type'              => 'select',
            'default'           => 'default',
            'options'           => array(
                'default'   => esc_html__( 'Default', 'sali-panels' ),
                'on'        => esc_html__( 'Enable', 'sali-panels' ),
                'off'       => esc_html__( 'Disable', 'sali-panels' ),
            ),
        ) );
		$cmb2_Page_header_footer_MataLayout->add_field( array(
			 'name'             =>  esc_html__( 'Footer Layout', 'sali-panels' ),
		    'id'               => $prefix.'_footer',
			'type'             => 'radio_image',
		    'default'          => 'default',
			'options'          => array(
				'default' => esc_html__( 'Default', 'sali-panels' ),
				'1'       => esc_html__( 'Layout 1', 'sali-panels' ),
				'2'       => esc_html__( 'Layout 2', 'sali-panels' ),
				'3'       => esc_html__( 'Layout 3', 'sali-panels' ),
			),
			'images_path'      => get_template_directory_uri(),
			'images'           => array(
				'default' => 'assets/img/header-footer-layout/footer-default.jpg',
				'1'       => 'assets/img/header-footer-layout/footer-01.jpg',
				'2'       => 'assets/img/header-footer-layout/footer-02.jpg',
				'3'       => 'assets/img/header-footer-layout/footer-03.jpg',
			)
		) );


		$cmb2_Page_header_footer_MataLayout = new_cmb2_box( array(
			'id'           => $prefix . '_page_header_footer_settings',
			'title'        => esc_html__( 'Header / Footer Settings', 'sali-panels' ),
			'object_types' => array('page','post'), // Post type
			'context'      => 'normal',
			'priority'     => 'high',
			'show_names'   => true, // Show field names on the left
		) );


	    $cmb2_Page_MataLayout->add_field( array(
		    'name'             =>  esc_html__( 'Content Padding Top', 'sali-panels' ),
		    'id'               => $prefix.'_top_padding',
		    'type'             => 'select',
		    'default'          => 'default',
		    'options'          => array(
	                'default' => esc_html__( 'Default', 'sali-panels' ),
					'0px'     => '0px',
					'10px'    => '10px',
					'20px'    => '20px',
					'30px'    => '30px',
					'40px'    => '40px',
					'50px'    => '50px',
					'60px'    => '60px',
					'70px'    => '70px',
					'80px'    => '80px',
					'90px'    => '90px',
					'100px'   => '100px',
		    ),
		) );
	    $cmb2_Page_MataLayout->add_field( array(
		    'name'             =>  esc_html__( 'Content Padding Bottom', 'sali-panels' ),
		    'id'               => $prefix.'_bottom_padding',
		    'type'             => 'select',
		    'default'          => 'default',
		    'options'          => array(
	                'default' => esc_html__( 'Default', 'sali-panels' ),
					'0px'     => '0px',
					'10px'    => '10px',
					'20px'    => '20px',
					'30px'    => '30px',
					'40px'    => '40px',
					'50px'    => '50px',
					'60px'    => '60px',
					'70px'    => '70px',
					'80px'    => '80px',
					'90px'    => '90px',
					'100px'   => '100px',
		    ),
		) );

	    $cmb2_Page_MataLayout = new_cmb2_box( array(
			'id'           => $prefix . '_page_banner_settings',
			'title'        => esc_html__( 'Banner Settings', 'sali-panels' ),
			'object_types' => array('page','post' ,'sali_services'), // Post type
			'context'      => 'normal',
			'priority'     => 'high',
			'show_names'   => true, // Show field names on the left
		) );
	$cmb2_Page_MataLayout->add_field( array(
		    'name'              =>  esc_html__( 'Banner', 'sali-panels' ),
		    'id'                => $prefix.'_banner',
		    'type'              => 'select',
		    'default'           => 'default',
		    'options'           => array(
	                'default'   => esc_html__( 'Default', 'sali-panels' ),
					'on'        => esc_html__( 'Enable', 'sali-panels' ),
					'off'       => esc_html__( 'Disable', 'sali-panels' ),
		    ),
		) );


		$cmb2_Page_MataLayout->add_field( array(
			'name'             =>  esc_html__( 'Breadcrumb', 'sali-panels' ),
			'id'               => $prefix.'_breadcrumb',
			'type'             => 'select',
			'default'          => 'default',
			'options'          => array(
			        'default'   => esc_html__( 'Default', 'sali-panels' ),
					'on'        => esc_html__( 'Enable', 'sali-panels' ),
					'off'       => esc_html__( 'Disable', 'sali-panels' ),
			),
		) );


		//  Team
		$cmb2_Team_MataLayout = new_cmb2_box( array(
		'id'           => $prefix . '_team_info',
		'title'        => esc_html__( 'Team Info', 'sali-panels' ),
		'object_types' => array('team'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		) );
		$cmb2_Team_MataLayout->add_field( array(
			'name'             =>  esc_html__( 'Designation', 'sali-panels' ),
			'id'               => $prefix.'_team_designation',
			'type'             => 'text',
			'default'          => '',
		) );

		$cmb2_Team_MataLayout->add_field( array(
			'name'     => esc_html__( 'Social Profile Information', 'sali-panels' ),
			'id'       => $prefix . '_extra_social_info',
			'type'     => 'title',
			'on_front' => false,
		) );

		$cmb2_Team_MataLayout->add_field( array(
			'name' => esc_html__( 'Facebook URL', 'sali-panels' ),
			'desc' => esc_html__( 'Please enter your facebook URL', 'sali-panels' ),
			'id'   => $prefix . '_facebook',
			'type' => 'text_url',
		) );
		$cmb2_Team_MataLayout->add_field( array(
			'name' => esc_html__( 'Twitter URL', 'sali-panels' ),
			'desc' => esc_html__( 'Please enter your twitter URL', 'sali-panels' ),
			'id'   => $prefix . '_twitter',
			'type' => 'text_url',
		) );
		$cmb2_Team_MataLayout->add_field( array(
			'name' => esc_html__( 'Linkedin URL', 'sali-panels' ),
			'desc' => esc_html__( 'Please enter your linkedin URL', 'sali-panels' ),
			'id'   => $prefix . '_linkedin',
			'type' => 'text_url',
		) );
		$cmb2_Team_MataLayout->add_field( array(
			'name' => esc_html__( 'Pinterest URL', 'sali-panels' ),
			'desc' => esc_html__( 'Please enter your pinterest URL', 'sali-panels' ),
			'id'   => $prefix . '_pinterest',
			'type' => 'text_url',
		) );


	// Post Layout
	$cmb2_post_layout = new_cmb2_box( array(
		'id'           => $prefix . '_post_layout_setting',
		'title'        => esc_html__( 'Post Layout Setting', 'sali-panels' ),
		'object_types' => array('post'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left

	) );
	$cmb2_post_layout->add_field( array(
		 'name'             =>  esc_html__( 'Select Post Layout', 'sali-panels' ),
		'id'               => $prefix.'_post_layout',
		'type'             => 'radio_image',
		'default'          => 'default',
		'options'          => array(
			'default' => esc_html__( 'Default', 'sali-panels' ),
			'1'       => esc_html__( 'Layout 1', 'sali-panels' ),
			'2'       => esc_html__( 'Layout 2', 'sali-panels' ),
			'3'       => esc_html__( 'Layout 3', 'sali-panels' ),
			'4'       => esc_html__( 'Layout 4', 'sali-panels' ),
			'5'       => esc_html__( 'Layout 5', 'sali-panels' ),
			'6'       => esc_html__( 'Layout 6', 'sali-panels' ),

		),
		'images_path'      => get_template_directory_uri(),
		'images'           => array(
			'default' => 'assets/img/post-layout/default.jpg',
			'1'       => 'assets/img/post-layout/post-layout-1.jpg',
			'2'       => 'assets/img/post-layout/post-layout-2.jpg',
			'3'       => 'assets/img/post-layout/post-layout-3.jpg',
			'4'       => 'assets/img/post-layout/post-layout-4.jpg',
			'5'       => 'assets/img/post-layout/post-layout-5.jpg',
			'6'       => 'assets/img/post-layout/post-layout-6.jpg',
		)
	) );

    // Page Template
    $cmb2_page_template_fixed = new_cmb2_box( array(
        'id'           => $prefix . '_page_template_fixed_settings',
        'title'        => esc_html__( 'Page Template Fixed Setting', 'sali-panels' ),
        'object_types' => array('page'), // Post type
        'context'      => 'normal',
        'priority'     => 'high',
        'show_names'   => true, // Show field names on the left
    ) );
    $cmb2_page_template_fixed->add_field( array(
        'name'              =>  esc_html__( 'Template Fixed', 'sali-panels' ),
        'id'                => $prefix.'_select_page_template_fixed',
        'type'              => 'select',
        'default'           => 'no',
        'options'           => array(
            'yes'        	=> esc_html__( 'Yes', 'sali-panels' ),
            'no'       		=> esc_html__( 'No', 'sali-panels' ),
        ),
    ) );


	}
}
new sali_metabox();
