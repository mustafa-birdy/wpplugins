<?php
/**
 * @author  Saliweb
 * @since   1.0
 * @version 1.0
 * @package sali-panels
 */


if( !class_exists( 'redux_panels' ) ){
	class redux_panels {	
		public function __construct() {
			$prefix = SALI_PANELS_THEME;		
			// Redux Flash permalink after options changed
			add_action( "redux/options/{$prefix}/saved", array( $this, 'sali_flush_redux_saved' ), 10, 2 );		
			add_action( "redux/options/{$prefix}/section/reset", array( $this, 'flush_redux_reset' ) );
			add_action( "redux/options/{$prefix}/reset", array( $this, 'flush_redux_reset' ) );
			
		}
		// Flush rewrites
		public function sali_flush_redux_saved( $saved_options, $changed_options ){
			if ( empty( $changed_options ) ) {
				return;
			}
			$prefix = SALI_PANELS_THEME;
			$flush  = false;
			$slugs  = array( 'team_slug' );
			foreach ( $slugs as $slug ) {
				if ( array_key_exists( $slug, $changed_options ) ) {
					$flush = true;
				}
			}
			if ( $flush ) {
				update_option( "{$prefix}_rewrite_flash", true );
			}
		}
		public function flush_redux_reset(){
			$prefix = SALI_PANELS_THEME;
			update_option( "{$prefix}_rewrite_flash", true );
		}
		
	}
	new redux_panels;
}