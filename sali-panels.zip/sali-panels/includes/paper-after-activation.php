<?php
if (!function_exists('paper_activate_core')) {
    function paper_activate_core()
    {
        $id = 'sali-sidebar-sidebar-for-about-page';
        $sidebars = get_option('paper_custom_sidebars', array());

        if (!array_key_exists($id, $sidebars)) {
            // wp_send_json_error(esc_html__('Sidebar with the same name already exists. Please choose a different name', 'paper'));
            $sidebars[$id] = array(
                'id' => $id,
                'name' => esc_html__('Sidebar For About Page ', 'paper'),
                'class' => 'sali-custom',
                'description' => '',
                'before_widget' => '<aside id="%1$s" class="widget-sidebar widget %2$s widgets-sidebar">',
                'after_widget' => '</aside>',
                'before_title' => '<div class="widget-title"><h3>',
                'after_title' => '</h3></div>',
            );
            update_option('paper_custom_sidebars', $sidebars);

        }

        // ---------------

        $id = 'sali-sidebar-sidebar-for-home-3';
        $sidebars = get_option('paper_custom_sidebars', array());

        if (!array_key_exists($id, $sidebars)) {
            //  wp_send_json_error(esc_html__('Sidebar with the same name already exists. Please choose a different name', 'paper'));
            $sidebars[$id] = array(
                'id' => $id,
                'name' => esc_html__('Sidebar For Home 3 ', 'paper'),
                'class' => 'sali-custom',
                'description' => '',
                'before_widget' => '<aside id="%1$s" class="widget-sidebar widget %2$s widgets-sidebar">',
                'after_widget' => '</aside>',
                'before_title' => '<div class="widget-title"><h3>',
                'after_title' => '</h3></div>',
            );
            update_option('paper_custom_sidebars', $sidebars);
        }


    }
}
