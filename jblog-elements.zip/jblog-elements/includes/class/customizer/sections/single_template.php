<?php

$options   = [];
$post_type = 'post-template';

$options[] = [
	'id'              => 'jbp[single_template_custom]',
	'option_type'     => 'option',
	'transport'       => 'postMessage',
	'default'         => '',
	'type'            => 'jeg-select',
	'label'           => esc_html__( 'Custom Post Template', 'jblog-elements' ),
	'description'     => wp_kses( sprintf( __( 'You can create custom post template from <a href="%s" target="_blank">here</a>.', 'jblog-elements' ), get_admin_url() . 'edit.php?post_type=' . $post_type ), wp_kses_allowed_html() ),
	'choices'         => jblog_get_all_custom_post_type( $post_type ),
	'postvar'         => [
		[
			'redirect' => 'single_tag',
			'refresh'  => true
		]
	]
];

return $options;
