<?php
do_action( 'jeg_archive_custom_template_header' );
do_action( 'jeg_render_archive', true, null );
do_action( 'jeg_archive_custom_template_footer' );