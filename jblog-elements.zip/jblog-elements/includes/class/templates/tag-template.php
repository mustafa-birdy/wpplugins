<?php get_header(); ?>
<div id="main" class="jeg-site-content">
	<div class="jeg-container">
		<?php jblog_render_custom_archive_template( 'tag' ); ?>
	</div>
</div>
<?php get_footer(); ?>
