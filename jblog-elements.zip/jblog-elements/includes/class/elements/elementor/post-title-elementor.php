<?php

namespace JBP\Elements\Elements\Elementor;

use Jeg\Element\Elementor\Elementor_Abstract;

/**
 * Class Post_Title_Elementor
 * @package JBP\Elements\Elements\Elementor
 */
class Post_Title_Elementor extends Elementor_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_elementor_id() {
		return 'jblog_post_title';
	}
}
