<?php

namespace JBP\Elements\Elements\Elementor;

use Jeg\Element\Elementor\Elementor_Abstract;

/**
 * Class Hero_1_Elementor
 * @package JBP\Elements\Elements\Elementor
 */
class Hero_1_Elementor extends Elementor_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_elementor_id() {
		return 'jblog_hero_1';
	}
}
