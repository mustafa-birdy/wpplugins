<?php

namespace JBP\Elements\Elements\Elementor;

use Jeg\Element\Elementor\Elementor_Abstract;

/**
 * Class Post_Comment_Elementor
 * @package JBP\Elements\Elements\Elementor
 */
class Post_Comment_Elementor extends Elementor_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_elementor_id() {
		return 'jblog_post_comment';
	}
}
