<?php

namespace JBP\Elements\Elements\Elementor;

use Jeg\Element\Elementor\Elementor_Abstract;

/**
 * Class Block_7_Elementor
 * @package JBP\Elements\Elements\Elementor
 */
class Block_7_Elementor extends Elementor_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_elementor_id() {
		return 'jblog_block_7';
	}
}
