<?php

namespace JBP\Elements\Elements\Divi;

use Jeg\Element\Divi\Divi_Builder_Abstract;

/**
 * Class Post_Comment_Divi
 * @package JBP\Elements\Elements\Divi
 */
class Post_Comment_Divi extends Divi_Builder_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_divi_id() {
		return 'jblog_post_comment';
	}
}
