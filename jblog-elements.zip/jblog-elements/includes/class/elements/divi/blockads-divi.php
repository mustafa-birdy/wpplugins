<?php

namespace JBP\Elements\Elements\Divi;

use Jeg\Element\Divi\Divi_Builder_Abstract;

/**
 * Class Blockads_Divi
 * @package JBP\Elements\Elements\Divi
 */
class Blockads_Divi extends Divi_Builder_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_divi_id() {
		return 'jblog_blockads';
	}
}
