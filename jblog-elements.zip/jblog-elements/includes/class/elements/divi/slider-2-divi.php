<?php

namespace JBP\Elements\Elements\Divi;

use Jeg\Element\Divi\Divi_Builder_Abstract;

/**
 * Class Slider_2_Divi
 * @package JBP\Elements\Elements\Divi
 */
class Slider_2_Divi extends Divi_Builder_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_divi_id() {
		return 'jblog_slider_2';
	}
}
