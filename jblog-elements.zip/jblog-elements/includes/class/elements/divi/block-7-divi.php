<?php

namespace JBP\Elements\Elements\Divi;

use Jeg\Element\Divi\Divi_Builder_Abstract;

/**
 * Class Block_7_Divi
 * @package JBP\Elements\Elements\Divi
 */
class Block_7_Divi extends Divi_Builder_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_divi_id() {
		return 'jblog_block_7';
	}
}
