<?php

namespace JBP\Elements\Elements\Divi;

use Jeg\Element\Divi\Divi_Builder_Abstract;

/**
 * Class Archive_Desc_Divi
 * @package JBP\Elements\Elements\Divi
 */
class Archive_Desc_Divi extends Divi_Builder_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_divi_id() {
		return 'jblog_archive_desc';
	}
}
