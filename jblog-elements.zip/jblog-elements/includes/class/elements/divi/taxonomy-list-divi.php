<?php

namespace JBP\Elements\Elements\Divi;

use Jeg\Element\Divi\Divi_Builder_Abstract;

/**
 * Class Taxonomy_List_Divi
 * @package JBP\Elements\Elements\Divi
 */
class Taxonomy_List_Divi extends Divi_Builder_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_divi_id() {
		return 'jblog_taxonomy_list';
	}
}
