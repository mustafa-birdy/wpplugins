<?php

namespace JBP\Elements\Elements\Widget;

use Jeg\Element\Widget\Widget_Abstract;

/**
 * Class Archive_Pagination_Widget
 * @package JBP\Elements\Elements\Widget
 */
class Archive_Pagination_Widget extends Widget_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_widget_id() {
		return 'jblog_archive_pagination';
	}
}
