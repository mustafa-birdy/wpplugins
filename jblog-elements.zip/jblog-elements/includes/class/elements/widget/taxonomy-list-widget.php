<?php

namespace JBP\Elements\Elements\Widget;

use Jeg\Element\Widget\Widget_Abstract;

/**
 * Class Taxonomy_List_Widget
 * @package JBP\Elements\Elements\Widget
 */
class Taxonomy_List_Widget extends Widget_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_widget_id() {
		return 'jblog_taxonomy_list';
	}
}
