<?php

namespace JBP\Elements\Elements\Widget;

use Jeg\Element\Widget\Widget_Abstract;

/**
 * Class Block_29_Widget
 * @package JBP\Elements\Elements\Widget
 */
class Block_29_Widget extends Widget_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_widget_id() {
		return 'jblog_block_29';
	}
}
