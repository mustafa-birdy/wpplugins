<?php

namespace JBP\Elements\Elements\Widget;

use Jeg\Element\Widget\Widget_Abstract;

/**
 * Class Post_Tag_Widget
 * @package JBP\Elements\Elements\Widget
 */
class Post_Tag_Widget extends Widget_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_widget_id() {
		return 'jblog_post_tag';
	}
}
