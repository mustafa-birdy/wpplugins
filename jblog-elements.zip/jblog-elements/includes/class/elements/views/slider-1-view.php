<?php

namespace JBP\Elements\Elements\Views;

/**
 * Class Slider_1_View
 * @package JBP\Elements\Elements\Views
 */
class Slider_1_View extends Slider_View_Abstract {

	/**
	 * Slider content
	 *
	 * @param $results
	 *
	 * @return mixed
	 */
	public function content( $results ) {
		$content = '';
		foreach ( $results as $key => $post ) {
			$primary_category  = $this->get_primary_category( $post->ID );
			$image             = $this->get_thumbnail( $post->ID, 'jeg-1140x570' );

			$content .=
				'<div class="slide_item">
                    ' . jblog_edit_post( $post->ID ) . '
                    <a href="' . get_permalink( $post ) . '" class="slide_img">' . $image . '</a>
                    <div class="slide_caption">
                        <div class="jeg_post_category">
                            ' . $primary_category . '
                        </div>
                        <h3 class="jeg_post_title">
                            <a href="' . get_the_permalink( $post ) . '">' . get_the_title( $post ) . '</a>
                        </h3>
                    </div>
                </div>';
		}

		return $content;
	}
}
