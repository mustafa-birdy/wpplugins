<?php

namespace JBP\Elements\Elements\Beaver;

use Jeg\Element\Beaver\Beaver_Builder_Abstract;

/**
 * Class Post_Related_Beaver
 * @package JBP\Elements\Elements\Beaver
 */
class Post_Related_Beaver extends Beaver_Builder_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_beaver_id() {
		return 'jblog_post_related';
	}

	/**
	 * Element group
	 *
	 * @return string
	 */
	public function get_beaver_group() {
		return esc_html__( 'JBlog Elements', 'jblog-elements' );
	}
}
