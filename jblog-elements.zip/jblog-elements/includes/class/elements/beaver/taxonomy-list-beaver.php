<?php

namespace JBP\Elements\Elements\Beaver;

use Jeg\Element\Beaver\Beaver_Builder_Abstract;

/**
 * Class Taxonomy_List_Beaver
 * @package JBP\Elements\Elements\Beaver
 */
class Taxonomy_List_Beaver extends Beaver_Builder_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_beaver_id() {
		return 'jblog_taxonomy_list';
	}

	/**
	 * Element group
	 *
	 * @return string
	 */
	public function get_beaver_group() {
		return esc_html__( 'JBlog Elements', 'jblog-elements' );
	}
}
