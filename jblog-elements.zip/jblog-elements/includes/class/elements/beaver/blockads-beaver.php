<?php

namespace JBP\Elements\Elements\Beaver;

use Jeg\Element\Beaver\Beaver_Builder_Abstract;

/**
 * Class Blockads_Beaver
 * @package JBP\Elements\Elements\Beaver
 */
class Blockads_Beaver extends Beaver_Builder_Abstract {

	/**
	 * Element ID
	 *
	 * @return string
	 */
	public function get_beaver_id() {
		return 'jblog_blockads';
	}

	/**
	 * Element group
	 *
	 * @return string
	 */
	public function get_beaver_group() {
		return esc_html__( 'JBlog Elements', 'jblog-elements' );
	}
}
