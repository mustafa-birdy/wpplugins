(function ($) {
    'use strict'

    $(document).ready(function () {
        if (elementorFrontend) {
            elementorFrontend.hooks.addAction('frontend/element_ready/widget', function ($scope) {
                $scope.jblog_slider()
                $scope.jblog_block()
            })
        }
    })
})(jQuery);
