(function ($) {
    'use strict'

    window.jblog_iframe = window.jblog_iframe || {};

    $(document).ready(function () {

        window.jblog_iframe.slider = function (model_id) {
            $("[data-model-id='" + model_id + "']").jblog_slider()
        }

        window.jblog_iframe.block = function (model_id) {
            $("[data-model-id='" + model_id + "']").jblog_block()
        }
    })
})(jQuery);
