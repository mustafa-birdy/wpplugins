(function ($) {
    'use strict'

    $(document).ready(function () {
    	if (FLBuilder) {
    		FLBuilder.addHook('didRenderLayoutComplete', function(){
    			var body = $('body')
    			body.jblog_slider()
    			body.jblog_block()
    		})
    	}
    })
})(jQuery);
