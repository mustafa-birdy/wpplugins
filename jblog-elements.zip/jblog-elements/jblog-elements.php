<?php
/*
	Plugin Name: JBlog Elements
	Plugin URI: http://jegtheme.com/
	Description: News, magazine, blog elements for WPBakery Page Builder, Elementor, Divi and Beaver Builder plugin
	Version: 1.1.1
	Author: Jegtheme
	Author URI: http://jegtheme.com
	License: GPL2
    Text Domain: jblog-elements
*/

defined( 'JBP_ELEMENTS' ) || define( 'JBP_ELEMENTS', 'jblog-elements' );
defined( 'JBP_ELEMENTS_NAME' ) || define( 'JBP_ELEMENTS_NAME', 'JBlog Elements' );
defined( 'JBP_ELEMENTS_VERSION' ) || define( 'JBP_ELEMENTS_VERSION', '1.1.1' );
defined( 'JBP_ELEMENTS_FILE' ) or define( 'JBP_ELEMENTS_FILE', __FILE__ );
defined( 'JBP_ELEMENTS_URL' ) || define( 'JBP_ELEMENTS_URL', plugins_url( JBP_ELEMENTS ) );
defined( 'JBP_ELEMENTS_DIR' ) || define( 'JBP_ELEMENTS_DIR', plugin_dir_path( __FILE__ ) );
defined( 'JBP_ELEMENTS_ID' ) || define( 'JBP_ELEMENTS_ID', 25299740 );

defined( 'JEG_THEME_URL' ) || define( 'JEG_THEME_URL', JBP_ELEMENTS_URL );
defined( 'JEG_ELEMENT_THEME_URL' ) || define( 'JEG_ELEMENT_THEME_URL', JBP_ELEMENTS_URL . '/lib/jeg-element' );

require_once JBP_ELEMENTS_DIR . 'lib/jeg-framework/bootstrap.php';
require_once JBP_ELEMENTS_DIR . 'lib/jeg-element/bootstrap.php';
require_once JBP_ELEMENTS_DIR . 'lib/epic-dashboard/bootstrap.php';
require_once JBP_ELEMENTS_DIR . 'includes/autoload.php';

require_once 'includes/helper.php';

JBP\Elements\Init::instance();
