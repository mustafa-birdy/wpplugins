=== 1.1.0 ===
- add option to set & force width on element

=== 1.0.0 ===
- Initial Release