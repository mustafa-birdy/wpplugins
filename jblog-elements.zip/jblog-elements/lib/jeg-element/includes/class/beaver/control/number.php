<# var field = data.field; #>
<div class="number-wrapper">
	<input class="widefat" type="text" id="{{ data.name }}" name="{{ data.name }}" min="{{ field.options.min }}" max="{{ field.options.max }}" step="{{ field.options.step }}" value="{{ data.value }}" />
</div>